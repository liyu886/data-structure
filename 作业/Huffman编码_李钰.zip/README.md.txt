姓名：李钰
学号：19335112

一、程序说明
本程序实现基于Huffman编码的文件压缩与解压程序
本程序的实验环境为Dev-C++或CodeBlocks,打开源文件时最好用Notepad++防止生成乱码

二、使用简介
（一）系统主界面
Please enter your choice
1.compress file
2.decompress file
3.exit


用户可根据自己的需求选择操作，或选择退出总系统。

输入1，即为压缩文件
输入2，即为解压文件
输入3，即为退出系统

这里输入1,显示

Please enter your choice
1.compress file
2.decompress file
3.exit
1
Please enter the file name with file extension.(eg:lalala.txt)

下面输入文件名 //！！！！！因为我的程序只能对txt文件进行操作，所以这里输入txt类型文件
test1.txt

显示

Please enter your choice
1.compress file
2.decompress file
3.exit
1
Please enter the file name with file extension.(eg:lalala.txt)
test1.txt
Compress successfully!
------------------------------------------------
Please enter your choice
1.compress file
2.decompress file
3.exit



输入2，则显示

Please enter your choice
1.compress file
2.decompress file
3.exit
2
Please enter the file name with extension.(eg:lalala.bin)
test1.bin                                   //！！！！！这里固定需要输入.bin文件，因为程序中我的压缩文件为二进制文件
Decompress successfully!
------------------------------------------------

