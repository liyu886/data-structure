#include<Windows.h>
#include <iostream>
#include <queue>
#include<iomanip>
#include <algorithm>
#include<time.h>
#define m 4
#define l 6
#define insert_num 50
using namespace std;

class delayTime{
    long long count;
public:
    delayTime(){
        count = 0;
    }
    void delay(){
        Sleep(20);
        count++;
    }
    long long getcount(){
        return count;
    }
};

struct record{
    int key;
    int value;
    record(int key = 0, int value = 0){
        this->key = key;
        this->value = value;
    }
};

struct node{
    bool leaf;
    int number;//该内部节点的key的个数，或者叶子节点block的个数
    int key[m + 1];
    record block[l + 1];
    node* child[m + 1];
    node* parent;

    node(){
        leaf = false;
        number = 0;
        parent = NULL;


        for(int i = 0; i < m - 1; i++){
            key[i] = 0;
        }

        for(int i = 0; i < m; i++){
            child[i] = 0;
        }

        for(int i = 0; i < l; i++){
            block[i] = record();
        }
    }

};
//获取输入节点在其父亲节点中的位置
int position(node* children) {
	if (children->parent == NULL)return 0;
	for (int i = 0; i < children->parent->number; i++) {
		if ((children->parent->child)[i] == children) {
			return i;
		}
	}
	return 0;
}
//向左移动记录以删除第一个记录
void erase_node_byleft(node* root, int i)
{
	for (int j = i; j < root->number-1; j++)
	{
		(root->block)[j].key = (root->block)[j + 1].key;
		(root->block)[j].value = (root->block)[j + 1].value;
	}
	root->number--;
}
//向右移动记录以腾出一个空位
void insert_node_byright(node* root, int i)
{
	for (int j = i; j < root->number; j++)
	{
		(root->block)[j+1].key = (root->block)[j].key;
		(root->block)[j+1].value = (root->block)[j].value;
	}
	root->number++;
}
//重载<号，使得结构体可以直接用sort函数排序
bool operator < (const record& a, const record& b) {
	return a.key < b.key;
}
//清空整个树
void clear(node*& root) {
	if (root == NULL){
		return;
	}
	if (!root->leaf) 
	{
		for (int i = 0; i < root->number; i++){
			clear(root->child[i]);
		} 
		delete root;
		root = NULL;
	}
	else {
		delete root;
		root = NULL;
		return;
	}
}
//判断节点是否满
bool FullNode(node* temp) {
	if (temp->leaf)return temp->number == l + 1;
	else return temp->number == m + 1;
}
//将节点中的所有key和child全部右移一位
void RightShift(node* parent, int pos) {
	for (int i = parent->number; i > pos; i--) {
		(parent->child)[i] = (parent->child)[i - 1];
		(parent->key)[i] = (parent->key)[i - 1];
	}
	parent->number++;
}


//层次遍历
void level_traverse(node* root) {
	if (root) {
		int i = 0;
		queue<node*> temp;
		queue<node*> myqueue;
		queue<node*> toZero;

		myqueue.push(root);
		node* curr;
		while (myqueue.size()) {
			int j = 0;
			temp = myqueue;
			myqueue = toZero;
            
			cout << endl;
			cout << "The " << i++ << " level" << endl;
			while (temp.size()) {
				curr = temp.front();
				temp.pop();
				int num = 0;
				if (curr) {
					num = curr->number;

				}
				else {
					continue;
				}
				if (curr->leaf) {
					cout << "leaf" << j++ << ":" << endl;
					for (int i = 0; i < num; i++) {
						cout << "[" << setw(3) << (curr->block)[i].key << " , " << setw(3) << (curr->block)[i].value << " ]" << "     ";
					}
            
					cout << endl;
					
				}
				else {
					cout << "node" << j++ << ":" << endl;
					for (int i = 0; i < num; i++) {
						myqueue.push(curr->child[i]);
						cout << setw(5) << curr->key[i];
					}
					cout << endl;
				}
				
			}
		}

	}
	else {
		cout << "Empty" << endl;
	}
}


//分裂
void split(node*& root, node*& target) {
	if (!FullNode(target))return;
	node* parent = target->parent;
	if (target->leaf) {//如果要分裂的节点是叶子
		int pos = position(target);//找到他在父亲节点对应的位置
		RightShift(target->parent, pos);//父亲节点里从他的位置开始（不包括他的位置）key值以及child全部向右移一位
        node* temp = new node;//新增节点
        temp->leaf = true;
        temp->parent = parent;
		(parent->child)[pos + 1] = temp;

		int new_target = (target->number + 1) / 2;//给原来叶子节点留至少一半的记录
		int new_leaf = target->number - new_target;//确定新增叶子结点的record数
		int MidKey = ((parent->child)[pos]->block)[new_target - 1].key;//更新原来叶子节点对应的父亲中的key值
		target->number = new_target;//更新原来叶子节点的record数
		(parent->child)[pos + 1]->number = new_leaf;//更新新增节点的record数
		for (int i = 0; i < new_leaf; i++) {//给新增节点的record赋值
			((parent->child)[pos + 1]->block)[i].key = ((parent->child)[pos]->block)[i + new_target].key;
            ((parent->child)[pos + 1]->block)[i].value = ((parent->child)[pos]->block)[i + new_target].value;
		}
        //更新父亲节点中key值
		(parent->key)[pos + 1] = (parent->key)[pos];
		(parent->key)[pos] = MidKey;
		if (FullNode(parent)){//判断父亲节点是否满？慢则继续分裂
            split(root, parent);
        }

	}
	else {//分裂的不是叶节点
		if (parent == NULL) {//分根
            node* newroot = new node;//新增根节点
            target->parent = newroot;
            newroot->parent = NULL;
            newroot->number = 2;
            (newroot->child)[0] = target;

            node* temp = new node;//新增分裂节点
            temp->parent = newroot;
            temp->leaf = target->leaf;

            (newroot->child)[1] = temp; 

            
			int new_target = (target->number + 1) / 2;//更新原节点number
			int new_number = target->number - new_target;//新增节点number
			int MidKey = (target->key)[new_target - 1];//找到原节点现在的最大值给root->key[0]赋值
			(newroot->key)[0] = MidKey;
		
			int LastKey = (target->key)[target->number - 1];//找到新增节点的最大值给根的第二个key赋值
			(newroot->key)[1] = LastKey;
			target->number = new_target;
			(newroot->child)[1]->number = new_number;

			for (int i = 0; i < new_number; i++) {
				((newroot->child)[1]->key)[i] = ((newroot->child)[0]->key)[i + new_target];
				((newroot->child)[1]->child)[i] = ((newroot->child)[0]->child)[i + new_target];
				((newroot->child)[0]->child)[i + new_target]->parent = (newroot->child)[1];
			}
			root = newroot;

		}
		else {//分裂的是非根内部节点，类似于叶结点的分裂只不过做区分的是内部节点改变的是key和child，而叶节点是block
			int pos = position(target);
			RightShift(target->parent,pos);
			(parent->child)[pos + 1] = new node;
			(parent->child)[pos + 1]->leaf = (parent->child)[pos]->leaf;
			(parent->child)[pos + 1]->parent = parent;

			int new_target = (target->number + 1) / 2;
			int new_leaf = target->number - new_target;
			int MidKey = ((parent->child)[pos]->key)[new_target - 1];
			target->number = new_target;
			(parent->child)[pos + 1]->number = new_leaf;
			for (int i = 0; i < new_leaf; i++) {
				((parent->child)[pos + 1]->key)[i] = ((parent->child)[pos]->key)[i + new_target];
				((parent->child)[pos + 1]->child)[i] = ((parent->child)[pos]->child)[i + new_target];
				((parent->child)[pos]->child)[i + new_target]->parent = (parent->child)[pos + 1];
			}
			(parent->key)[pos + 1] = (parent->key)[pos];
			(parent->key)[pos] = MidKey;
			if (FullNode(parent)) {
				split(root, parent);
			}
			


		}
	}

}
//向叶子中增加记录
void AddToleaf(node* leaf, record target) {
	if (!leaf->leaf)return;
	(leaf->block)[leaf->number].key = target.key;
    (leaf->block)[leaf->number].value = target.value;

	leaf->number++;
	sort(leaf->block, leaf->block + leaf->number);

}
//使叶节点平衡


void leaf_balance(node*& root, delayTime& decelerator){
    if(root->number >= (l + 1) / 2) return;//如果叶子节点够直接返回
    if(!(root->parent)){//若该叶节点是根
        if(root->number == 0){//且该叶节点的元素已经被删完了
            root = NULL;
            return;
        }
    }

    node* parents = root->parent;
    int index = position(root);
    if(index == 0){//若该节点在最左端，只能向右兄弟借
        decelerator.delay();
        node* right_brother = (parents->child)[1];
        if(right_brother->number > (l + 1) / 2){//若右兄弟的元素够他挥霍
            (root->block)[root->number].key = (right_brother->block)[0].key;
            (root->block)[root->number].value = (right_brother->block)[0].value;
            root->number++;

            (parents->key)[0] = (right_brother->block)[0].key;
            erase_node_byleft(right_brother, 0);
        }

        else{//右兄弟正好满足半满，不够给他借了，合并

            //先将兄弟节点的元素复制给他
            for(int i = 0; i < right_brother->number; i++){
                (root->block)[root->number + i].key = (right_brother->block)[i].key;
                (root->block)[root->number + i].value = (right_brother->block)[i].value;
                root->number++;
            }
            //删除右兄弟
            delete right_brother;
            //更新parents
            for(int i = 0; i < parents->number - 1; i++){
                (parents->key)[i] = (parents->key)[i + 1];//parents的所有key值向前移一位
                if(i != 0){
                    (parents->child)[i] = (parents->child)[i + 1];//从第三个孩子开始，所有的child向前移一个
                }
            }
            parents->number--;

        }

    }
    else if(index == parents->number - 1){//若该结点在最右端,只能向左兄弟借
        decelerator.delay();
        node* left_brother = (parents->child)[index - 1];
        if(left_brother->number > (l + 1) / 2){//左兄弟的元素够
            insert_node_byright(root, 0);//给借来的节点腾出空位
            (root->block)[0].key = (left_brother->block)[left_brother->number - 1].key;
            (root->block)[0].value = (left_brother->block)[left_brother->number - 1].value;
            left_brother->number--;
            (parents->key)[index - 1] = (left_brother->block)[left_brother->number - 1].key;
        }
        else{//左兄第元素不够，合并
            for(int i = 0; i < root->number; i++){//合并到左兄第上
                (left_brother->block)[left_brother->number + i].key = (root->block)[i].key;
                (left_brother->block)[left_brother->number + i].value = (root->block)[i].value;
                left_brother->number++;
            }
            //删掉原节点
            delete root;
            root = NULL;
            (parents->key)[index - 1] = (parents->key)[index];
            parents->number--;
        }
    }
    else{//中间节点
       node* left_brother = (parents->child)[index - 1];
       node* right_brother = (parents->child)[index + 1];
       decelerator.delay();
       decelerator.delay();

       if(left_brother->number > (l + 1) / 2){
            insert_node_byright(root, 0);
            (root->block)[0].key = (left_brother->block)[left_brother->number - 1].key;
            (root->block)[0].value = (left_brother->block)[left_brother->number - 1].value;
            left_brother->number--;
            (parents->key)[index - 1] = (left_brother->block)[left_brother->number - 1].key;
       }

       else if(right_brother->number > (l + 1) / 2){
            (root->block)[root->number].key = (right_brother->block)[0].key;
            (root->block)[root->number].value = (right_brother->block)[0].value;
            root->number++;

            (parents->key)[index] = (right_brother->block)[0].key;
            erase_node_byleft(right_brother, 0);
       }
       else{//都不够给他借，和左兄第合并
            for(int i = 0; i < root->number; i++){//合并到左兄第上
                (left_brother->block)[left_brother->number + i].key = (root->block)[i].key;
                (left_brother->block)[left_brother->number + i].value = (root->block)[i].value;
                left_brother->number++;
            }
            //删掉原节点
            delete root;
            root = NULL;
            (parents->key)[index - 1] = (parents->key)[index];
            for(int i = index; i < parents->number - 1; i++){
                (parents->key)[i] = (parents->key)[i + 1];
                (parents->child)[i] = (parents->child)[i + 1];
            }
            parents->number--;
       }
    }
    
}

//使内部节点平衡
void internal_balance(node*& root, delayTime& decelerator){
    node* parents = root->parent;
    if(!parents){//是根
        if(root->number == 1){
            root = (root->child)[0];
            delete root->parent;
            root->parent = NULL;
        }
        return ;
    }
    if(root->number >= (m + 1) / 2){
        return ;
    }
    int index = position(root);
    if(index == 0){
        decelerator.delay();
        node* right_brother = (parents->child)[1];
        if(right_brother->number > (m + 1) / 2){//若右兄弟的元素够他挥霍
            //先借一个过来
            (root->key)[root->number] = (right_brother->key)[0];
            (root->child)[root->number] = (right_brother->child)[0];
            (right_brother->child)[0]->parent = root;//记得改变借的节点的父节点
            root->number++;

            //更新父节点
            (parents->key)[0] = (right_brother->key)[0];
            //右兄弟整体向左移
            for(int i = 0; i < right_brother->number - 1; i++){
                (right_brother->key)[i] = (right_brother->key)[i + 1];
                (right_brother->child)[i] = (right_brother->child)[i + 1];

            }
            right_brother->number--;
        }

        else{//右兄弟正好满足半满，不够给他借了，合并

            //先将兄弟节点的元素复制给他
            for(int i = 0; i < right_brother->number; i++){
                (root->key)[root->number + i] = (right_brother->key)[i];
                (root->child)[root->number + i] = (right_brother->child)[i];
                (right_brother->child)[i]->parent = root;
                root->number++;
            }
            //删除右兄弟
            delete right_brother;
            //更新parents
            for(int i = 0; i < parents->number - 1; i++){
                (parents->key)[i] = (parents->key)[i + 1];//parents的所有key值向前移一位
                if(i != 0){
                    (parents->child)[i] = (parents->child)[i + 1];//从第三个孩子开始，所有的child向前移一个
                }
            }
            parents->number--;
        }
    }
    else if(index == parents->number - 1){
        decelerator.delay();
        node* left_brother = (parents->child)[index - 1];
        if(left_brother->number > (m + 1) / 2){//左兄弟的元素够
            //腾位置
            for(int i = 0; i < root->number; i++){
                (root->key)[i + 1] = (root->key)[i];
                (root->child)[i + 1] = (root->child)[i];
            }

            (root->key)[0] = (left_brother->key)[left_brother->number - 1];
            (root->child)[0] = (left_brother->child)[left_brother->number - 1];
            (left_brother->child)[left_brother->number - 1]->parent = root;
            root->number++;
            left_brother->number--;
            (parents->key)[index - 1] = (left_brother->key)[left_brother->number - 1];
        }
        else{//左兄第元素不够，合并
            for(int i = 0; i < root->number; i++){//合并到左兄第上
                (left_brother->key)[left_brother->number + i] = (root->key)[i];
                (left_brother->child)[left_brother->number + i] = (root->child)[i];
                (root->child)[i]->parent = left_brother;////
                left_brother->number++;
            }
            //删掉原节点
            delete root;
            root = NULL;
            (parents->key)[index - 1] = (parents->key)[index];
            parents->number--;
        }
    }
    else{
        node* left_brother = (parents->child)[index - 1];
        node* right_brother = (parents->child)[index + 1];
        decelerator.delay();
        decelerator.delay();

        if(left_brother->number > (m + 1) / 2){
            for(int i = 0; i < root->number; i++){
                (root->key)[i + 1] = (root->key)[i];
                (root->child)[i + 1] = (root->child)[i];
            }

            (root->key)[0] = (left_brother->key)[left_brother->number - 1];
            (root->child)[0] = (left_brother->child)[left_brother->number - 1];
            (left_brother->child)[left_brother->number - 1]->parent = root;
            root->number++;
            left_brother->number--;
            (parents->key)[index - 1] = (left_brother->key)[left_brother->number - 1];
        }

        else if(right_brother->number > (l + 1) / 2){
            //先借一个过来
            (root->key)[root->number] = (right_brother->key)[0];
            (root->child)[root->number] = (right_brother->child)[0];
            (right_brother->child)[0]->parent = root;//记得改变借的节点的父节点
            root->number++;

            //更新父节点
            (parents->key)[index] = (right_brother->key)[0];
            //右兄弟整体向左移
            for(int i = 0; i < right_brother->number - 1; i++){
                (right_brother->key)[i] = (right_brother->key)[i + 1];
                (right_brother->child)[i] = (right_brother->child)[i + 1];

            }
            right_brother->number--;
        }
        else{//都不够给他借，和左兄第合并
            for(int i = 0; i < root->number; i++){//合并到左兄第上
                (left_brother->key)[left_brother->number + i] = (root->key)[i];
                (left_brother->child)[left_brother->number + i] = (root->child)[i];
                (root->child)[i]->parent = left_brother;////
                left_brother->number++;
            }
            //删掉原节点
            delete root;
            root = NULL;
            //更新父亲

            (parents->key)[index - 1] = (parents->key)[index];
            for(int i = index; i < parents->number - 1; i++){
                (parents->key)[i] = (parents->key)[i + 1];
                (parents->child)[i] = (parents->child)[i + 1];
            }
            parents->number--;
        }
    }
    
}
//插入操作
bool insert(node*& root, record target, delayTime& delayer) {
	if (root == NULL) {
		root = new node;
		root->leaf = false;
		root->number = 1;
		root->parent = NULL;
		(root -> key)[0] = target.key;
		(root->child)[0] = new node;

		node* temp = (root->child)[0];
		temp->number = 1;
		temp->leaf = true;
		temp->parent = root;
		(temp->block)[0].key = target.key;
        (temp->block)[0].value = target.value;
        delayer.delay();
		return true;
	}
	node* myqueue = root;
	if (target.key > (root->key)[root->number - 1]) {//target.key是目前子树中最大的，向下一直找到要插入的叶子
		while (!myqueue->leaf) {
			(myqueue->key)[myqueue->number - 1] = target.key;
			myqueue = (myqueue->child)[myqueue->number - 1];
			delayer.delay();
		}
		AddToleaf(myqueue, target);

	}
	else {
		while (!myqueue->leaf) {
			int pos = 0;
			for (int i = 0; i < myqueue->number; i++) {
				if ((myqueue->key)[i] > target.key) {
					pos = i;
					break;
				}
                if ((myqueue->key)[i] == target.key) {
					return false;
				}
			}
			myqueue = (myqueue->child)[pos];
			delayer.delay();
		}
		for (int i = 0; i < myqueue->number; i++) {
			if (myqueue->block[i].key == target.key) {
				return false;
			}
		}
		AddToleaf(myqueue, target);
	}
    //spile(root, myqueue);
	split(root, myqueue);
	return true;
}
//删除操作
bool remove(node*& root, int target, delayTime& decelerator){

    if(root->leaf){
        for(int i = 0; i < root->number; i++){
            if((root->block)[i].key == target){
                if(i > 0 && i == root->number - 1){//特殊情况，要删除的关键字在其父节点甚至爷爷节点都可能会出现
                    int temp = (root->block)[i - 1].key;

                    node* cur = root;
                    while(cur->parent){
                       
                        int index = position(cur);//找到待删除元素在其父节点的位置
                        (cur->parent->key)[index] = temp;//更新父结点中的元素值

                        if(cur->parent->number - 1 == index){//若其好修改的父节点的关键字在其爷爷节点中也出现，还需要再修改爷爷节点
                            cur = cur->parent;//如果爷爷正好是根？？？？？？？？
                        }
                        else{
                            break;
                        }
                    }

                }

                erase_node_byleft(root, i);//删除root节点中的第i + 1个,将其右边的元素同步左移
                leaf_balance(root, decelerator);
                return true;
            }
        }
        return false;//没有找到待删除的元素
    }
    else{
        for(int i = 0; i < root->number; i++){
            if(target <= (root->key)[i]){
                decelerator.delay();
                bool temp = remove((root->child)[i], target, decelerator);//一直递归，直到找到叶节点
                internal_balance(root, decelerator);
                return temp;
            }
        }
        return false;
    }
    
}
//查找操作
bool search(node* root, int target){
    if(root == NULL){
        return false;
    }
    node* ptr = root;
    while(ptr != NULL){
        if(ptr->leaf){
            for(int i = 0; i < ptr->number; i++){
                if(target == (ptr->block)[i].key){
                	cout << "Find it! It's in the leaf node. " << endl;
					cout << "The key of record is " << target <<" and the value of it is " << (ptr->block)[i].value << endl;
                    return true;
                }
            }
            return false;
        }
        else{
            int index = 0;
            for(int i = 0; i < ptr->number; i++){
                if((ptr->key)[i] < target){
                    index++;
                }
                else if((ptr->key)[i] == target){
                	cout << "Find it! It's in the internal node.";
                    return true;
                }
                else{
                    break;
                }
            }
            ptr = (ptr->child)[index];
        }
    }
}
//获得随机记录
record get_rand(){
	return record(rand() % 234, rand() % 234);
}
//插入测试
void test_insert(node*& root){
    cout << "------------------This is an insert operation test------------------" << endl;
    delayTime insert_time;

    int count = 0;
	for (int i = 0; i < insert_num; i++)
	{
		count += insert(root, get_rand(), insert_time);
	}
	int time = insert_time.getcount() * 0.02;
    cout << endl;
	cout << "Try to insert " << insert_num << " random record " << time << " s" << endl;
	cout << "Insert successfully " << count << " records!" << endl;
    cout << "The level traverse of the B plus tree is as follow." << endl;
    cout << endl << endl;
	level_traverse(root);
    cout << endl << endl;

    cout << "Do you want to insert more records?" << endl;
    cout << "1 --> Yes" << endl;
    cout << "0 --> No" << endl;

    int choice;
    cin >> choice;
    if(choice){
        int number;
        cout << "Please enter the number of records." << endl;
        cin >> number;
        cout << "Please enter the keys and values in one line and separate by space." << endl;
        cout << "Like:key1 value1 key2 value2 key3 value3" << endl;

        count = 0;
        while(number--){
            int key, value;
            cin >> key >> value;
            record temp(key, value);
            count += insert(root, temp, insert_time);
            
        }
        cout << "Insert successfully " << count << " records!" << endl;
        cout << "The level traverse of the B plus tree is as follow." << endl;
        cout << endl << endl;
        level_traverse(root);
        cout << endl << endl;
    }

    cout << "-------------Insert operation test is over.-------------------" << endl;
    
	//clear(root);
}
//查找测试
void test_search(node* root){

	cout << endl << endl;
	cout << "------------------This is a search operation test------------------" << endl;
	cout << "Please enter the times that you want to do search operation." << endl;
	int times;
	cin >> times;
	while(times--){
		int target;
		cout << "Please enter the key of record which you want to search." << endl;
		cin >> target;
		bool temp = search(root, target);
		if(!temp){
			cout << "Don't find!" << endl;
		}
	}
	
	cout << "-------------Search operation test is over.-------------------" << endl;
}
//删除测试
void test_remove(node*& root){
	cout << endl << endl;
	cout << "------------------This is a remove operation test------------------" << endl;
	delayTime remove_time;
	int count = 0;
	for (int i = 0; i < insert_num; i++)
	{
		count += remove(root, get_rand().key, remove_time);
	}
	cout << "Try to delete " << insert_num << " random records, use " << 0.02 * remove_time.getcount() << "s" << endl;
	cout << "Deelete successfully " << count << "records. " << endl;
	cout << "The level traverse of the B plus tree is as follow." << endl;
	level_traverse(root);
	
	cout << "Do you want to delete more records?" << endl;
    cout << "1 --> Yes" << endl;
    cout << "0 --> No" << endl;

    int choice;
    cin >> choice;
    if(choice){
        int number;
        cout << "Please enter the number of records." << endl;
        cin >> number;
        cout << "Please enter the keys of record which you want to delete." << endl;
        cout << "Like:key1 key2 key3" << endl;

        count = 0;
        while(number--){
            int key;
            cin >> key;
            
            count += remove(root, key, remove_time);
        }
        cout << "Delete successfully " << count << " records!" << endl;
        cout << "The level traverse of the B plus tree is as follow." << endl;
        cout << endl << endl;
        level_traverse(root);
        cout << endl << endl;
    }
	cout << "-------------Remove operation test is over.-------------------" << endl;
}

int main()
{
	node* root = NULL;
	srand(time(NULL));//设置种子

    test_insert(root);
    test_search(root);
    test_remove(root);
    clear(root);
    if(!root){
    	cout << "The root has been deleted!" << endl;
	}

	return 0;
}

