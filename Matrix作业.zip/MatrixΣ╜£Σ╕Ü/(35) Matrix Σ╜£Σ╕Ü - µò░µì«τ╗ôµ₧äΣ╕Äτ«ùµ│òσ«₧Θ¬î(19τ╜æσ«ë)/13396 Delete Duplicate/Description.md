# Delete Duplicate

## 题目描述
已知线性表中的元素以递增有序排列，并以单链表作存储结构。试写一个高效的算法，删除表中所有冗余的结点，即数据域相同的结点只保留一个。  
链表结点定义如下：
```cpp
struct LinkNode {
	int data;
	LinkNode *next;
	LinkNode(int d, LinkNode *add_on = NULL) {
		data = d;
		next = add_on;
	}
};
typedef LinkNode *LinkList;
```
请实现函数：  
```cpp
#include "deleteDuplicate.h"

void delete_duplicate(LinkList &head);
```
**注意内存的回收。**