#include <iostream>
#include "deleteDuplicate.h"

void delete_duplicate(LinkList &head){
    LinkNode *p = head ;
    LinkNode *tmp ;
    
    if (p == NULL || p -> next == NULL )        return ;
    else {
        while ( p ){
            tmp =  p -> next ;
            if ( tmp ){
                if (tmp -> data == p -> data ){
                    p -> next = tmp -> next ;
                    free(tmp) ;
                    continue;
                } 
            }
            p = p -> next ;
        }
    }
}