#include "deleteDuplicate.h"
void delete_duplicate (LinkList &head)
{
    LinkList a, b;
    a = head;
    for (; ; )
    {
        if (a == NULL)
        {
            break;
        }
        b = a->next;
        if (b == NULL)
        {
            break;
        }
        if (b->data == a->data)
        {
            a->next = b->next;
            delete b;
        }
        else
        {
            a = a->next;
        }
    }
}