#include <cstddef>
#ifndef DELETEDUPLICATE_H_INCLUDED
#define DELETEDUPLICATE_H_INCLUDED
struct LinkNode {
    int data;
    LinkNode *next;
    LinkNode(int d, LinkNode *add_on = NULL) {
        data = d;
        next = add_on;
    }
};
typedef LinkNode *LinkList;
void delete_duplicate(LinkList &head);

#endif // DELETEDUPLICATE_H_INCLUDED
