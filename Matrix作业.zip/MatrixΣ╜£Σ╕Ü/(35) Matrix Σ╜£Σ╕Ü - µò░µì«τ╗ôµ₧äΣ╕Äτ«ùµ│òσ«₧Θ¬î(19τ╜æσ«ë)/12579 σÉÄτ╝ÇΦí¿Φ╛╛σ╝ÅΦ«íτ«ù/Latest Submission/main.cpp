#include <iostream>
#include <stack>
#include <string>
#include <iomanip>

using namespace std ;

int main () {
    
    string str ;
    stack <float> temp ;
    float sum = 0 ;
    float num1 ;
    float num2 ;

    cin >> str ;

    for ( int i = 0 ; i < str.length() ; ++ i){

        if (str[i] >= 'a' && str[i] <= 'z')  temp.push(str[i]-96) ;
        else if ( str[i] == '*') {
           
            num1 = temp.top() ; 
            temp.pop() ;
            num2 = temp.top() ; 
            temp.pop() ;
            sum = num1 * num2 ;
            temp.push( sum ) ;
        }
        else if ( str[i] == '/') {
            num1 = temp.top() ; 
            temp.pop() ;
            num2 = temp.top() ; 
            temp.pop() ;
            sum = num2 / num1 ;
            temp.push( sum ) ;
        }
        else if ( str[i] == '+') {
            num1 = temp.top() ; 
            temp.pop() ;
            num2 = temp.top() ; 
            temp.pop() ;
            sum = num1 + num2 ;
            temp.push( sum ) ;
        }
        else if ( str[i] == '-') {
            num1 = temp.top() ; 
            temp.pop() ;
            num2 = temp.top() ; 
            temp.pop() ;
            sum = num2 - num1 ;
            temp.push( sum ) ;
        }
    }

    cout<<setiosflags(ios::fixed);
    //cout.setf(ios::fixed);
    cout << setprecision(2) << sum ;

    system("pause");
}