#include <iostream>
#include <queue>
#include <string>

using namespace std ;

int main (){
    int num_operation ;
    queue<int> q ;
    int temp ;

    cin >> num_operation ;


    for ( int i = 0 ; i < num_operation ; ++i ) {
        string str ;
        cin >> str ;
        if ( str == "In" ){
            cin >> temp ;
            q.push(temp) ;
        } 
     
        if ( str == "Out"){
            if ( q.empty() )          cout << -1  << endl ;
            else  {
                cout << q.front() << endl ;
                q.pop() ;
            }
        }
        if ( str == "Count") {
            int tmp ;
            tmp = q.size()  ;
            cout <<  tmp  << endl ;

        } 
    }
}