#include <cstdio>
#include <queue>
#include <cstring>
#include <vector>

using namespace std;

int inDegree[100010];
struct cmp {
    bool operator()(const int &i, const int &j) {
        return (i > j);
    }
};
vector<int> isLinked[100010];
priority_queue<int, vector<int>, cmp> queueToSort;
int n, length;
int resultList[100010];

int main() {
    int t, m, a, b;
    scanf("%d", &t);
    while(t--) {
        // initialize
        scanf("%d", &n);
        memset(inDegree, 0, (100010)*sizeof(int));
        for(int i = 1; i < n+1; i++) {
            isLinked[i].clear();
        }

        scanf("%d", &m);
        // read in 
        while(m--) {
            scanf("%d%d", &a, &b);
            isLinked[a].push_back(b);
            inDegree[b]++;
        }

        for (int i = 1; i <= n; i++) {
            if (0 == inDegree[i]) { queueToSort.push(i); };
        }
        int firstNode;
        length = 0;
        while(!queueToSort.empty()){
            firstNode = queueToSort.top();
            queueToSort.pop();
            // output
            resultList[length] = firstNode;
            length++;
            // delete edges
            for (int i = 0; i < isLinked[firstNode].size(); i++) {
                inDegree[isLinked[firstNode][i]]--;
                if (0 == inDegree[isLinked[firstNode][i]]) {
                    queueToSort.push(isLinked[firstNode][i]);
                }
            }
        }
        for(int i = 0; i < length; i++) {
            printf("%d ", resultList[i]);
        }
        printf("\n");
    }
    return 0;
}
