#include <iostream>
#include <vector>
#include <queue>
#include <memory.h>
using namespace std;
int main()
{
int numTestcases;
cin >> numTestcases;
while(numTestcases --){
int n, m;
cin >> n >> m;
int inDegree[n + 1]; //入度为0数组
int result[n]; //结果序列
vector<int> tasks[n + 1]; //每一组vector都有该结点的后继结点
memset(inDegree, 0, sizeof(inDegree)); //初始化
for (int i = 0; i < m; ++ i){
int a, b;
cin >> a >> b;
inDegree[b] ++;
tasks[a].push_back(b);
}
priority_queue<int, vector<int>, greater<int> > readyTasks;//使用最小优先队列可以自动按照从小到大排序
for (int i = 1; i <= n; ++ i)//先将所有根结点放进队列中待选
{
if(inDegree[i] == 0) readyTasks.push(i);
}
int numFinished = 0;
while(!readyTasks.empty())
{
int cur = readyTasks.top();
result[numFinished++] = cur;
readyTasks.pop();
vector<int>::iterator it;
for(it = tasks[cur].begin(); it != tasks[cur].end(); it ++){
int temp = *it;
inDegree[temp] --;
if(inDegree[temp] == 0) readyTasks.push(temp);//当前趋结点全部完成时可以开始这个任务
}
}
for (int i = 0; i < n; ++ i)
{
cout << result[i] << " ";
}
cout << endl;
}
}