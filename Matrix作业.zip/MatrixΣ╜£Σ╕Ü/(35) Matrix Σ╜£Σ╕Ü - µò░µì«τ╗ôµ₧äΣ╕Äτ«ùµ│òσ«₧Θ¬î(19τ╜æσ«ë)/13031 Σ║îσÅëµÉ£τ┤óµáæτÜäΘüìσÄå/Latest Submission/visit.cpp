#include <iostream>
using namespace std;

//二叉查找树的节点结构
template <typename T>
struct BSNode
{
	BSNode(T t)
	: value(t), lchild(nullptr), rchild(nullptr){}
	
	BSNode() = default;

	T value;
	BSNode<T>* lchild;
	BSNode<T>* rchild;
	BSNode<T>* parent;
};

//二叉查找树类
template <typename T>
class BSTree
{
public:
	BSTree();
	~BSTree();

	void preOrder();	//前序遍历二叉树
	void inOrder();		//中序遍历二叉树	
	void insert(T key);	//插入指定值节点
	void destory();		//销毁二叉树

private:
	BSNode<T>* root; //根节点
private:
	BSNode<T>* search(BSNode<T>* & p, T key); 
	void preOrder(BSNode<T>* p);
	void inOrder(BSNode<T>* p);
	void destory(BSNode<T>* &p);		
	
};

/*默认构造函数*/
template <typename T>
BSTree<T>::BSTree() :root(nullptr){};

/*析构函数*/
template <typename T>
BSTree<T>::~BSTree()
{
	destory(root);
};

/*插入函数*/
template <typename T>
void BSTree<T>::insert(T key)
{
	BSNode<T>* pparent = nullptr;
	BSNode<T>* pnode = root;

	while (pnode != nullptr)		//寻找合适的插入位置
	{
		pparent = pnode;
		if (key > pnode->value)
			pnode = pnode->rchild;
		else if (key < pnode->value)
			pnode = pnode->lchild;
		else
			break;
	}

	pnode = new BSNode<T>(key);
	if (pparent == nullptr)			//如果是空树
	{
		root = pnode;				//则新节点为根
	}
	else
	{
		if (key > pparent->value)	
		{
			pparent->rchild = pnode;//否则新节点为其父节点的左孩
		}
		else
			pparent->lchild = pnode;//或右孩
	}
	pnode->parent = pparent;		//指明新节点的父节点

};

/*前序遍历算法*/
template <typename T>
void BSTree<T>::preOrder()
{
	preOrder(root);
};
template <typename T>
void BSTree<T>::preOrder(BSNode<T> *p)
{
	if (p != nullptr)
	{
		cout << p->value << ' ';
		preOrder(p->lchild);
		preOrder(p->rchild);
	}
};

/*中序遍历算法*/
template <typename T>
void BSTree<T>::inOrder()
{
	inOrder(root);
};
template<typename T>
void BSTree<T>::inOrder(BSNode<T>* p)
{
	if (p != nullptr)
	{
		inOrder(p->lchild);
		cout << p->value << ' ';
		inOrder(p->rchild);
	}
};

/*销毁二叉树*/
template<typename T>
void BSTree<T>::destory()
{
	destory(root);
};
template <typename T>
void BSTree<T>::destory(BSNode<T>* &p)
{
	if (p != nullptr)
	{
		if (p->lchild != nullptr)
			destory(p->lchild);
		if (p->rchild != nullptr)
			destory(p->rchild);
		delete p;
		p = nullptr;
	}

};

int main () {
    int n ;
    std:: cin >> n ;

    while ( n != 0){
		BSTree<int> t;
        //if (n == 0 )    break ;
        for (int i = 0 ; i < n ; ++ i){
            int a ;
            std :: cin >> a ;
            t.insert(a) ;
        }
		t.inOrder() ;
    	std:: cout << '\n' ;
    	t.preOrder() ;
        std::cout << '\n' ;
		t.destory() ;
        std::cin >> n ;
    }

   
}