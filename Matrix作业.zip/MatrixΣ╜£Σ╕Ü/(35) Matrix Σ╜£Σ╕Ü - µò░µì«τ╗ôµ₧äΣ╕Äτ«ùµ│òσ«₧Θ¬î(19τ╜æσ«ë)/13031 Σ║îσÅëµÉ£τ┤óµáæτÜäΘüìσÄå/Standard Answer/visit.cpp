#include <iostream>
using namespace std;

struct BSTnode{
    int data;
    BSTnode *lchild;
    BSTnode *rchild;
};

void insert(BSTnode *root,int add)
{
    BSTnode *temp,*p;
    temp = root;
    while(1)
    {
        if(add > temp->data)
        {
            if(temp->rchild == NULL)
            {
                p = new BSTnode;
                p->data = add;
                p->lchild = NULL;
                p->rchild = NULL;
                temp->rchild = p;
                break;
            }
            else temp = temp->rchild;    
        }
        else
        {
            if(temp->lchild == NULL)
            {
                p = new BSTnode;
                p->data = add;
                p->lchild = NULL;
                p->rchild = NULL;
                temp->lchild = p;
                break;
            }
            else temp = temp->lchild;
        }   
    }
    
}

void preorder(BSTnode *temp)
{
    if(temp != NULL)
    {
        cout<<temp->data<<" ";
        preorder(temp->lchild);
        preorder(temp->rchild);
    }
}

void inorder(BSTnode *temp)
{
    if(temp != NULL)
    {
        inorder(temp->lchild);
        cout<<temp->data<<" ";
        inorder(temp->rchild);
    }
}

int main()
{ 
    int n,m;
    while(cin>>n)
    {
        if(n==0) 
        break;
        else
        {
            BSTnode *root;
            root = new BSTnode;
            root->lchild = NULL;
            root->rchild = NULL;
            
            cin>>m;
            root->data = m;  
            for(int i=0;i<n-1;i++)
            {
                cin>>m;
                insert(root,m);
            }
            inorder(root);
            cout<<endl;
            preorder(root); 
            cout<<endl;
        }
    }
}