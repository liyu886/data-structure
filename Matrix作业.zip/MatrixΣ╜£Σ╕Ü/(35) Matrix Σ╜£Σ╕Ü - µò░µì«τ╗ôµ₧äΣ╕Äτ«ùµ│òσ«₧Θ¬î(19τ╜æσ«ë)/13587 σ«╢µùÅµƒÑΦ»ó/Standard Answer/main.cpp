#include <iostream>  
#include <cstring>  
#include <cstdio>  
#include <cstdlib>  
#include<stdio.h>

using namespace std;

int father[50000], a, b, m, n, p;
//�ҵ�x������   
int find(int x) {
    if (father[x] != x) {
        father[x] = find(father[x]);
        return father[x];
    }
}


int main() {
    int q;
    int i;
    scanf("%d", &q);
    while (q--) {

        scanf("%d", &n);
        scanf("%d", &m);
        for (i = 1;i <= n;i++) {
            father[i] = i;
        }

        for (i = 1;i <= m;i++) {
            scanf("%d", &a);
            scanf("%d", &b);
            a = find(a);
            b = find(b);
            father[a] = b;
        }

        cin >> p;
        for (i = 1;i <= p;i++) {
            scanf("%d", &a);
            scanf("%d", &b);
            a = find(a);
            b = find(b);
            if (a == b) {
                printf("Yes\n");
            }
            else printf("No\n");
        }
        if (q != 0) {
            printf("\n");
        }
    }

    return 0;
}