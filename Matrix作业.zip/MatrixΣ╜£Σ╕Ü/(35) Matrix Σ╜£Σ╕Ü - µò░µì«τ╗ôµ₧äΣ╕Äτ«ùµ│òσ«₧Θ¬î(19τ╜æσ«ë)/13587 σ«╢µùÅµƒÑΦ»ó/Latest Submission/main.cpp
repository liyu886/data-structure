#include <iostream>
#include <cstring>
#include <cstdio>
#include <cstdlib>
using namespace std;
int father[5001];

int find(int x)
{
    if(father[x] != x)
    {
        father[x] = find(father[x]);
        return father[x];
    }
} 
int main()
{
    int T;
    cin >> T;
    while(T --)
    {
        int n, m;
        cin >> n >> m;
        for(int i = 1; i <= n; i ++)
        {
            father[i] = i;
        }
        int u, v;
        for(int i = 1; i <= m; i ++)
        {
            cin >> u >> v;
            u = find(u);
            v = find(v);
            father[u] = v;
        }
        int q;
        cin >> q;
        for(int i = 1; i <= q; i ++)
        {
            cin >> u >> v;
            u = find(u);
            v = find(v);
            if(u == v) cout << "Yes" << endl; 
            else cout << "No" << endl;
        }
    }
    return 0;
}