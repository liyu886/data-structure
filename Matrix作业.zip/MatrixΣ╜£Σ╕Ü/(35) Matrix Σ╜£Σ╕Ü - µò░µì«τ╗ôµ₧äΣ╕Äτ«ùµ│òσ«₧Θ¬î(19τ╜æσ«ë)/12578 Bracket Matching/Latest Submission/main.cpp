#include <iostream>
#include <stack>
#include <string>

#define MAX 10

using namespace std ;

int main () {
    //int n = MAX ;

    //while ( n -- ){

        string str ;
        cin >> str ;
        stack <char> temp ;

        for (int i = 0 ; i < str.length() ; ++ i){
            if ( str[i] == '(' || str[i] == '{' || str[i] == '[')               temp.push(str[i]) ;

            else if (str[i] == ')'){
                if ( temp.empty() )                     temp.push(str[i]) ;  
                else {
                    if ( temp.top()== '(' )             temp.pop( ) ;
                    else                                temp.push(str[i]) ;
                }
            }

            else if ( str[i] == '}'){
                if ( temp.empty() )                     temp.push(str[i]) ;
                else {
                    if ( temp.top() == '{')             temp.pop( ) ;
                    else                                temp.push(str[i]) ;
                }
            }

            else if ( str[i] == ']'){
                if ( temp.empty() )                     temp.push(str[i]) ;
                else {
                    if ( temp.top() == '[' )            temp.pop( ) ;
                    else                                temp.push(str[i]) ;
                }
            }
        }

        if( temp.empty() )                              cout << "Yes\n" ;
        else                                            cout << "No\n"  ; 
    //}
    
}