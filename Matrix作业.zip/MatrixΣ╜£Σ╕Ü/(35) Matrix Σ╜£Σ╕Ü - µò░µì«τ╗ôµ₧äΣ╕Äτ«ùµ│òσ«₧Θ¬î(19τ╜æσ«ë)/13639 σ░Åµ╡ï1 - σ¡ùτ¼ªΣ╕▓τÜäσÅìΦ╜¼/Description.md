# 小测1 - 字符串的反转

## 问题描述：
给定一个字符串，你需要颠倒一个句子中每个单词中的字符顺序，同时保留空格和初始单词顺序。

## 输入样例：
Let's take the contest
## 输出样例：
s'teL ekat eht tsetnoc