#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<iomanip>
#include<algorithm> 

using namespace std;
int main(){
    string s1;
    int count = 0;
    getline(cin,s1);
    s1 = s1 + " ";
    int len_number = s1.length();
    for(int i = 0;i < len_number; i++){
    if(s1[i] == ' '){
        for(int j = i - 1; j >= count; j--){
            cout<<s1[j];
         }
        cout<<" ";
        count = i + 1;
        }
    }
    //return 0;
}