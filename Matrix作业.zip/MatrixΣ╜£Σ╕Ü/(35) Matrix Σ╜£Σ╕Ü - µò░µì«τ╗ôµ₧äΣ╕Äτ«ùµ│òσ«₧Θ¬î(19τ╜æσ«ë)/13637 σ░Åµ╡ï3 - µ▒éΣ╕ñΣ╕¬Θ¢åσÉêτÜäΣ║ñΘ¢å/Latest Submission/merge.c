#include<iostream>
#include"SeqList.h"

using namespace std;

void merge(SeqList *LA, SeqList *LB, SeqList *LC)
{
    if (LA->last == -1 || LB->last == -1) return;
    LC->last = 0;
    int num1 = 0, num2 = 0;
    while(num1 <= LA->last && num2 <= LB->last)
    {
        if (LA->elem[num1] == LB->elem[num2])
        {
            LC->elem[LC->last] = LA->elem[num1];
            LC->last ++;
            num1 ++;
            num2 ++;
        }
        if (LA->elem[num1] < LB->elem[num2]) num1 ++;
        if (LA->elem[num1] > LB->elem[num2]) num2 ++;
    }
    LC->last --;
}