#include "SeqList.h"

void merge(SeqList *LA, SeqList *LB, SeqList *LC)
{
    int i,j,k,l;
    i=0;
    j=0;
    k=0;
    while(i<=LA -> last && j<=LB ->last)
    {
        if(LA -> elem[i]< LB -> elem[j])
        {
            i++;
        }
        else  if(LA-> elem[i] > LB -> elem[j])
        {
            j++;
        }
        else
        {
            LC -> elem[k]=LA -> elem[i];
            i++;
            j++;
            k++;
        }
    }
    if (k>0)
        LC->last=k - 1;

}
