#include<iostream>
using namespace std;

void merge_sort(int* A, int x, int y, int* T)     //排序
{
    if(y - x > 1)                                 //跳出递归条件
    {
        int mid = (x + y) / 2;
        int begin = x, end = mid, i = x;
        merge_sort(A, x, mid, T);                 //排序左半部分
        merge_sort(A, mid, y, T);                 //排序右半部分
        while(begin < mid || end < y)
        {
            if(end >= y || (begin < mid && A[begin] <= A[end])) T[i ++] = A[begin ++];
            else T[i ++] = A[end ++];
        }
        for(int i = x; i < y; i ++)
        {
            A[i] = T[i];
        }
    }
}

int main()
{
    int n;
    while(cin >> n)                               //输入n个数据
    {
        int A[n], T[n];                           //A数组存储输入的数据，T数组为暂时存储空间
        int t[n] = {0};                           //t标记是否为重复数
        int number = n;                           //number为非重复数的个数并初始化为n
        for(int i = 0; i < n; i ++)               
        {
            cin >> A[i];
        }
        merge_sort(A, 0, n, T);                    //排序
        for(int i = 0; i < n - 1; i ++)            //计算非重复的个数
        {
            if(A[i] == A[i+1])
            {
                number -= 1;                       //如果遇到重复的就减去1
                t[i] = 1;                          //标记这一位为重复的
            }
        }
        cout << number << endl;                    //输出非重复数的个数
        for(int i = 0; i < n; i ++)
        {
            if(t[i] != 1)
            {
                cout << A[i] << " ";               //输出非重复的数
            }
        }
    }
}
