# Robot

## 题目描述
Karell Incorporated has designed a new exploration robot that has the ability to explore new terrains, this new robot can move in all kinds of terrain, it only needs more fuel to move in rough terrains, and less fuel in plain terrains. The only problem this robot has is that it can only move orthogonally, the robot can only move to the grids that are at the North, East, South or West of its position.  
The Karell`s robot can communicate to a satellite dish to have a picture of the terrain that is going to explore, so it can select the best route to the ending point, The robot always choose the path that needs the minimum fuel to complete its exploration, however the scientist that are experimenting with the robot, need a program that computes the path that would need the minimum amount of fuel. The maximum amount of fuel that the robot can handle is 9999 units.  
The Terrain that the robot receives from the satellite is divided into a grid, where each cell of the grid is assigned to the amount of fuel the robot would need to pass thought that cell. The robot also receives the starting and ending coordinates of the exploration area.  
![](https://bucket-picgo-issac.oss-cn-shenzhen.aliyuncs.com/img/1004_1.gif)
## 输入描述
The first line of the input file is the number of tests that must be examined.  
The first line of the test is the number of rows and columns that the grid will contain. The rows and columns will be 0 < row ≤100, 0 < column ≤ 100.  
The next lines are the data of the terrain grid.  
The last line of the test has the starting and ending coordinates.  
## 输出描述
One line, for each test will have the amount of fuel needed by the robot.  
## 输入样例
3  
5 5  
1 1 5 3 2  
4 1 4 2 6  
3 1 1 3 3  
5 2 3 1 2  
2 1 1 1 1  
1 1 5 5  
5 4  
2 2 15 1  
5 1 15 1  
5 3 10 1  
5 2 1 1  
8 13 2 15  
1 1 1 4  
10 10  
1 1 1 1 1 1 1 1 1 1  
1 1 1 1 1 1 1 1 1 1  
1 1 1 1 1 1 1 1 1 1  
1 1 1 1 1 1 1 1 1 1  
1 1 1 1 1 1 1 1 1 1  
1 1 1 1 1 1 1 1 1 1  
1 1 1 1 1 1 1 1 1 1  
1 1 1 1 1 1 1 1 1 1  
1 1 1 1 1 1 1 1 1 1  
1 1 1 1 1 1 1 1 1 1  
1 1 10 10  
## 输出样例
10  
15  
19  
