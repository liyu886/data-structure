#include <iostream>  
#include <cstring>  
#include <queue>  
using namespace std;  
int dir_x[] = {-1, 0, 1, 0};      
int dir_y[] = {0, 1, 0, -1};  
struct Node {  
    int x;  
    int y;  
    int cost;  
    Node(int a, int b, int c) {  
        x = a;  
        y = b;  
        cost = c;  
    }  
    friend bool operator < (Node a, Node b) {  
        return a.cost > b.cost;     
    }  
};  
  
int main() {  
    int t;  
    int city[101][101];  
    bool visit[101][101];            
    cin >> t;  
    while (t--) {  
        int m, n;  
        cin >> m >> n;  
        memset(visit, false, sizeof(visit));  
        for (int i = 1; i <= m; i++) {  
            for (int j = 1; j <= n; j++) {  
                cin >> city[i][j];  
            }  
        }  
        int s_x, s_y, e_x, e_y;      
        cin >> s_x >> s_y >> e_x >> e_y;  
        visit[s_x][s_y] = true;  
        priority_queue<Node> q;  
        q.push(Node(s_x, s_y, city[s_x][s_y]));  
        Node top = q.top();          
        while (!visit[e_x][e_y]) {  
            for (int i = 0; i < 4; i++) {  
                int x = top.x + dir_x[i];  
                int y = top.y + dir_y[i];  
                if (x >= 1 && x <= m && y >= 1 && y <= n && !visit[x][y]) {  
                    q.push(Node(x, y, top.cost + city[x][y]));  
                }  
            }  
            top = q.top();          
            while (visit[top.x][top.y]) {  
                q.pop();  
                top = q.top();;  
            }  
            visit[top.x][top.y] = true;  
        }  
        cout << top.cost << endl;  
    }  
    return 0;  
}