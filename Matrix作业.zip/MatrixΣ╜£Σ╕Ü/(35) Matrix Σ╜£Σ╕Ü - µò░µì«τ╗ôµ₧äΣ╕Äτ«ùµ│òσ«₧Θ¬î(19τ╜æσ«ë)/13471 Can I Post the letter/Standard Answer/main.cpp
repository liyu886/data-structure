#include <iostream>
using namespace std;

void DFS(const int i,int &N,int (&E)[200][200],int (&visited)[200])
{
    visited[i] = 1;
    for (int j=0;j<N;j++)
    {
        if (E[i][j] == 1)
        {
            if (!visited[j])
                DFS(j,N,E,visited);
        }
    }
}

int main()
{
    int N = 0,M = 0;
    while (cin>>N && N)
    {
        int E[200][200] = {0};
        int i,j;    
        cin>>M;
        for (int t=0;t<M;t++)
        {
            cin>>i>>j;
            E[i][j] = 1;
        }
        
        int visited[200] = {0};
        DFS(0,N,E,visited);
        
        if (visited[N-1])
            cout<<"I can post the letter"<<endl;
        else
            cout<<"I can't post the letter"<<endl;
    }
    
    return 0;
}