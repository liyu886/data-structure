#include <iostream>
#include "play.h"
using namespace std;

int get_height(const Node* node) {
    if(node == NULL) {
        return 0;
    }
    else {
        int left_h = get_height(node -> lc);
        int right_h = get_height(node -> rc);
        int max = left_h;
        if(right_h > max) {
        max = right_h;
    }
    return max + 1;
    }
}

int get_size(const Node* node) {
    if(node == NULL) {
        return 0;
    }
    else {
        int left_s = get_size(node -> lc);
        int right_s = get_size(node -> rc);
        int num = left_s + right_s;
        return num + 1;
    }
}

void query(const Node *root, int &size, int &height) {
    size = get_size(root);
    height = get_height(root);
}