#include<iostream>
#include "play.h"
using namespace std;


int Height(const Node *root)  
{  
    int lheight, rheight;  
    if(root== NULL)  
        return 0;  
    else  
    {  
        lheight = Height(root->lc) + 1;  
        rheight = Height(root->rc) + 1;  
    }  
    if(lheight>rheight)
    return lheight;
    else
    return rheight;
}  

int count(const Node*root)
{
    if(root==0) return 0;
    return count(root->lc) + count(root->rc) + 1;
}


void query(const Node *root, int &size, int &height)
{ size=count(root);
    height=Height(root);
    
}