# Play with Tree

## 题目描述
Given a binary tree, your task is to get the height and size(number of nodes) of the tree.
The Node is defined as follows.
```cpp
struct Node {
Node *lc, *rc;
char data;
};
```
Implement the following function.  
```cpp
void query(const Node *root, int &size, int &height)
{
// put your code here
}
```
## 提示
 In this problem, we assume that the height of the tree with only one node is 1.