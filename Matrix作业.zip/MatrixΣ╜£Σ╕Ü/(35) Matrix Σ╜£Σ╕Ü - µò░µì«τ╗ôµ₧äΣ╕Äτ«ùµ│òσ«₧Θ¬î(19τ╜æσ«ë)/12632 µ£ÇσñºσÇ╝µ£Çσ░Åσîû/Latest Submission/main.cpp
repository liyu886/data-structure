#include<iostream>
#include<string.h>
using namespace std;
int a[200000];
int n,m;//数组有n个数，分成m组

int check(int max,int a[]){
    int i=0,sum,count=0;
    while(i<n){ 
        sum=0;
        while(i<n&&sum+a[i]<=max){
            sum+=a[i++];
        }
        count++;
    }
    return count;
}

int main(){
    do{ 
        memset(a,0,sizeof(a));
        cin >> n;
        int low = 0 , high = 0 ;
        cin >> m ;

        for( int i = 0 ; i < n ; i++){
            cin >> a[i] ; 
            high += a[i] ;
            if( a[i] > low)                 low = a[i] ;
        }
        while( low < high){
            int mid = (low+high)/2;
            int k = check(mid,a) ;
            if ( k <= m )                   high = mid ;
            else                            low = mid + 1 ;
        }
        if(low != 0 )
        cout << low << endl;
    }
    while( getchar() != EOF) ; 
}