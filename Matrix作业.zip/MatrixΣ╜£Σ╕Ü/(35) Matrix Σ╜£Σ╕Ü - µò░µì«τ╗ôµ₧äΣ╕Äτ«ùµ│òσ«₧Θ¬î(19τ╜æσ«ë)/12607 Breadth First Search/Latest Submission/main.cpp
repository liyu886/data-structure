#include<iostream>
#include<queue>

using namespace std;

const int maxn = 100;
int map[maxn][maxn] = {0};
int visited[maxn] = {0};

bool BFS(int N, int S, int T){
    int t = 0;
    queue<int> q;
    for (int j = 0; j < N; j ++){         
        if (map[S][j] == 1 && visited[j] == 0){
            if (j == T){
                t = 1;
                return 1;
            }
            else{
                q.push(j);
                visited[S] = 1;       //why? supposed to be j
            }
        }
    }
    while (!q.empty()){
        int q_top = q.front();
        q.pop();
        for (int j = 0; j < N; j ++){
            if (map[q_top][j] == 1 && visited[j] == 0){            //whether chongfu?
                if (j == T){
                    t = 1;
                    return 1;
                }
                else{
                    q.push(j);
                    visited[q_top] = 1;
                }
            }
        }
    }
    if (!t) return 0;
}

int main()
{
    int N, S, T;
    cin >> N >> S >> T;
    for (int i = 0; i < N; i ++){
        for (int j = 0; j < N; j ++){
            cin >> map[i][j];
        }
    }
    if (BFS(N, S, T))               cout << "yes\n" ;
    else                            cout << "no\n" ;
}

