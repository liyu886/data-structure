#include <iostream>
#include <queue>
#include <stack>

using namespace std;

int main() {
    int test, T, S, N;
    int i, j, temp, q, n, flag;
    int visited[100];
    stack<int> node[100];
    while(cin >> N >> S >> T) {
        for (i = 0; i < 100; i++) {
            visited[i] = 0;
        }
        
        for (i = 0; i < N; i++)
            for (j = 0; j < N; j++) {
                cin >> temp;
                if (temp == 1)
                    node[i].push(j);
            }
        flag = 1;
    
        queue<int> que;
        que.push(S);
        while(!que.empty() && flag) {
            q = que.front();
            que.pop();

            while(!node[q].empty()) {
                n = node[q].top();
                node[q].pop();
                
                if(!visited[n]) {
                    if (n == T) {
                        cout << "yes" << endl;
                        flag = 0;
                        break;
                    } 
                    else {
                        que.push(n);
                        visited[n] = 1;
                    }
                }
            }
            visited[q] = 1;
        }
        if(flag)
            cout << "no" << endl;
    }
    return 0;
}