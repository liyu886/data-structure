# Breadth First Search

## 题目描述
Breadth-first search (BFS) is a strategy for searching in a graph. You are given a graph with N nodes, a starting node S and an ending node T. You are required to answer whether there exists a path from S to T.

## 输入描述
The first line of a test case is an integer N (N<=100), S and T (0<=S,T<N).
The next N lines, each line contains N binary numbers. If the i-th row and j-th column is 1, node i is connected with node j.
Otherwise, there is no edge between i and j.

## 输出描述
Output "yes" if there exists a path from S to T. Otherwise, output "no".

## 样例输入
5 0 3

1 1 0 0 0

1 1 0 0 1

0 0 1 0 0

0 0 0 1 1

0 1 0 1 1

## 样例输出
yes