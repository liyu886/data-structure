#include<iostream>
using namespace std;
int vers, edges;

void DFS(int v, int * visited, int ** matrix){
	visited[v] = 1;
	for(int i = 0; i < vers; ++i){
		if((!visited[i]) && matrix[v][i]){
			DFS(i, visited, matrix);
		}	
	}
}

int main(){

	cin >> vers >> edges;

	int ** matrix = new int*[vers];
	for(int i = 0; i < vers; ++i)           matrix[i] = new int[vers];
	for(int i = 0; i < vers; ++i){
		for(int j = 0; j < vers; ++j){
			matrix[i][j] = 0;
		}
	}
	int * visited = new int[vers];
	for(int i = 0; i < vers; ++i){
		visited[i] = 0;	
	}
	
		
	for(int i = 0; i < edges; ++i){
		int a, b;
		cin >> a >> b;
		matrix[a - 1][b - 1] = matrix[b - 1][a - 1] = 1 ; 
	}
	
	int blo = 0;
	for(int i = 0; i < vers; ++i){
		if(!visited[i]){
			blo++;
			DFS(i, visited, matrix);
		}
	}
	
	cout << blo << endl;
}
