#include <iostream>
#include <algorithm>
using namespace std;

const int INF = 0x7fffffff;
int d[105][105];

void floyd(int n) {
    for(int k = 1; k <= n; ++k) {
        for(int i = 1; i <= n; ++i) {
            if(d[i][k] == INF)
                continue;
            for(int j = 1; j <= n; ++j) {
                if(d[k][j] == INF)
                    continue;
                d[i][j] = min(d[i][j], d[i][k] + d[k][j]);
            }
        }
    }
}

int main() {
    int N, K, Q;
    cin >> N >> K >> Q;
    for(int i = 1; i <= N; ++i) {
        for(int j = 1; j <= N; ++j) {
            d[i][j] = i == j ? 0 : INF;
        }
    }

    int u, v, c;
    for(int i = 0; i < K; ++i) {
        cin >> u >> v >> c;
        if(d[u][v] == INF)
            d[u][v] = c;
        else
            d[u][v] = d[u][v] < c ? d[u][v] : c;
    }

    floyd(N);

    for(int i = 0; i < Q; ++i) {
        cin >> u >> v;
        if(d[u][v] == INF)
            cout << "-1" << endl;
        else
            cout << d[u][v] << endl;
    }
    return 0;
}