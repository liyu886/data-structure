#include<iostream>
int INF= 1000000;
using namespace std;
void Floyd(int N, int**D, int**G){
    for (int i = 0; i < N; i++){
        for (int j = 0; j < N; j++) {
            D[i][j] = G[i][j];
        }
    }
    for (int k = 0; k < N; k++){
        for (int i = 0; i < N; i++){
            for (int j = 0; j < N; j++) {
                if (D[i][k] < INF&&D[k][j] < INF){
                    if (D[i][k] + D[k][j] < D[i][j]){
                        D[i][j] = D[i][k] + D[k][j];
                        //cout << " D[i][k] + D[k][j]" << i << ' ' << k << ' ' << j << endl;
                    }
                }

            }
        }
    }
}

int main(){
    int n, k, q;
    cin >> n >> k >> q;
    int **G, **D;
    G = new int*[n];
    D = new int*[n];
    for (int i = 0; i < n; i++){
        G[i] = new int[n];
        D[i] = new int[n];
    }
    for (int i = 0; i < n; i++)
    for (int j = 0; j < n; j++){
        G[i][j] = INF;
        if (i == j)
            G[i][j] = 0;
    }
    for (int i = 0; i < k; i++){
        int a, b, c;
        scanf("%d%d%d", &a, &b, &c);
        if (G[a - 1][b - 1]>c)
            G[a - 1][b - 1] = c;
    }

    Floyd(n, D, G);

    for (int i = 0; i < q; i++){
        int a, b;
        scanf("%d%d", &a, &b);
        if (D[a - 1][b - 1]<INF )
            printf("%d\n", D[a - 1][b - 1]);
        else
            printf("-1\n");
    }

    return 0;
}
