#include"mergeSort.h"
#include<iostream>
using namespace std;
void mergesort(linkedlist *&head, int len)
{
    if(len > 1)
    {
        linkedlist *left  = head;
        linkedlist *p  = head;
        for(int i = 0; i < len / 2 - 1; i ++)    //把链表分为两段（等长，或第二段比第一段大一）
        {
            p = p->next;                         //找到第一段的最后一个结点
        }
        linkedlist *right = p->next;             //指针指向第二段的首个结点
        p->next = NULL;                          //将第一段最后一个结点指向空
        mergesort(left, len / 2);                //排序左半部分
        mergesort(right, len - len / 2);         //排序右半部分
        head = left;
        linkedlist *lptr = left;
        linkedlist *rptr = right;
        linkedlist *t = lptr;                    //暂存
        while(lptr != NULL && rptr != NULL)
        {
            if((lptr->data) <= (rptr->data))
            {
                t = lptr;                        //t指向lptr当前位置的前一个元素，方便插入
                lptr = lptr->next;               //符合顺序，lptr后移
            }
            else
            {
                if(t == lptr)                    //查看暂存位置，判断lptr是不是第一个结点           
                {
                    t = rptr;                    //将暂存挪到要插入的结点
                    rptr = rptr->next;           //rptr向后移
                    t->next = lptr;              //将结点插入到头结点位置
                    left = t;
                    head = t;
                }
                else                             //查看暂存位置，如果lptr不是第一个结点
                {                                //将rptr结点插入到左半部分
                    t->next = rptr;
                    t = t->next;
                    rptr = rptr->next;
                    t->next = lptr;
                } 
            }
        }
        if(lptr == NULL)                         //如果左链表空了，将右半部分链表接上
        {
            if(rptr != NULL) t->next = rptr;
        }
    }

}
