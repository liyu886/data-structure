# Mergesort for List

## 题目描述
Please use mergesort to sort a linked list of data.
The linked list is defined as follows.
```cpp
struct linkedlist{
 int data;
 linkedlist *next;
 };
```

Please implement the following function.
```cpp
#include "mergeSort.h"
//sort the list by mergesort and return the head of it
void mergesort(linkedlist *&head, int len){
 //add your code here
}
```
## 提示
1->3->2->4->NULL
其中 1 是 head
