#include <iostream>  
#include <queue>  
#include <vector>  
using namespace std;
struct cmp {
    bool operator()(int a, int b)
    {
        return a > b;
    }
};
int main()
{
    int n, frequency, BT = 0;
    char character;
    priority_queue<int, vector<int>, cmp> f; 
    cin >> n;
    for (int i = 0; i < n; i++) {
        cin >> character >> frequency;
        f.push(frequency);
    }
    while (f.size()>1) {
        int tmp1, tmp2, tmp;
        tmp1 = f.top();
        f.pop();
        tmp2 = f.top();
        f.pop();
        tmp = tmp1 + tmp2;
        f.push(tmp); 
        BT = tmp1 + tmp2 + BT;
    }
    cout << BT << endl;
    return 0;
}
