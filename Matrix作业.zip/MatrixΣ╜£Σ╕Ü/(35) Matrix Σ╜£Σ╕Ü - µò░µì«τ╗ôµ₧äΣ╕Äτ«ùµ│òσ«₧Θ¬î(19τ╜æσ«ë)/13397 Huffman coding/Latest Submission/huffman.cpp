#include<iostream>
#include<string>
#include <vector>
 
using namespace std;
 
//节点结构
struct Node{
    char ch;
    int weight;
    Node *leftChild, *rightChild;
};
 
 
//插入排序
void insertSort(Node** nodeArray, int low, int high)
{
    for(int i = low + 1; i < high; i++)
    {
        Node* temp = nodeArray[i];
        int j = i - 1;
        while(j >= low && nodeArray[j]->weight > temp->weight)
        {
            nodeArray[j+1] = nodeArray[j];
            j--;
        }
        nodeArray[j+1] = temp;
    }
}
 
//建Hffman树
void createHuffman(Node** nodeArray, int n)
{
 
    insertSort(nodeArray, 0, n);    //先对节点按weight排序
    int p = 0;
    int res = 0;
    while(p < n - 1)
    {
        Node* minNode1 = nodeArray[p];  //找出weight值最小的两个
        Node* minNode2 = nodeArray[++p];
        Node* newNode = new Node;
        newNode->weight = minNode1->weight + minNode2->weight;  //合并生成新的节点
        res += newNode->weight;
 
        newNode->leftChild = minNode1;
        newNode->rightChild = minNode2;
        nodeArray[p] = newNode;
        insertSort(nodeArray, p, n);
    }
 
    cout << res <<endl;
}
 
 
int main()
{
    int n;
    cin >> n;
    char ch;
    int weight;
    Node* nodeArray[n];
    for(int i = 0; i < n; i++)
    {
        Node* node = new Node;
        cin >> ch >> weight;
        node->ch = ch;
        node->weight = weight;
        nodeArray[i] = node;
    }
    createHuffman(nodeArray, n);
    return 0;
}

