#include<iostream>
using namespace std;

long long int inverse_num = 0;                    
void inverse_number(int* A, int x, int y, int* T){
    if(y - x > 1){
        int mid = x + (y - x) / 2;
        int begin = x, end = mid, i = x;
        inverse_number(A, x, mid, T);             
        inverse_number(A, mid, y, T);             
        while(begin < mid || end < y){
            if(end >= y || (begin < mid && A[begin] <= A[end]))
                T[i ++] = A[begin ++];
            else{
                T[i ++] = A[end ++]; 
                inverse_num += (mid - begin) ;     
            }
        }

        for(int i = x; i < y;i ++){
            A[i] = T[i];
        }
    }
}

int main(){
    int n;
    while(cin >> n){
        int A[n];
        int T[n];
        for(int i = 0; i < n; i ++){
            cin>>A[i];
        }
        inverse_num = 0;                       
        inverse_number(A, 0, n, T);
        cout << inverse_num << endl;
        
    }
}
