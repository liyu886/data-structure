# Inversion Number

## 题目描述
Let A(1), ..., A(n) be a sequence of n numbers. If i<j and A(i)>A(j), then the pair (i,j) is called an inversion pair.
The inversion number of a sequence is one common measure of its sortedness. Given the sequence A, calculate its inversion number.
## 输入描述
There are multiple cases.
Each case contains an integer n (n<=100,000) followed by A(1) , ..., A(n).
## 输出描述
For each case, output the inversion number.
## 输入样例
5  
3 1 4 5 2
## 输出样例
4
## 提示
The answer may exceed 2^31.