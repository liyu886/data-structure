#include<iostream>
#include<cstdio>
#include<algorithm>
using namespace std;

int CityNumber,roads;
int HaveBuilt= 0; //CityNumber端点总数，roads边数，HaveBulit已经连接了多少边 
int fat[501];//记录集体老大 

struct node{
int from;
int to;
int distance;//结构体储存边 
}edge[200001];

bool cmp(const node &node1, const node &node2){//sort排序{
    return node1.distance< node2.distance;
}

int father(int num){//找集体老大，并查集的一部分 
    return ( fat[num] == num )?num: fat[num]=father(fat[num]);
}

void Union(int x,int y)//加入团体，并查集的一部分 
{
fat[father(y)]=father(x);
}

int main()
{
int number;
int minimum;

cin >> number;
while(number--){
cin >> CityNumber;//输入点数，边数 
minimum = 0;
HaveBuilt =0;
int dis;
int count = 0;

for(int i = 1 ;i <= CityNumber;i++)
 {   
  for(int j = 1;j <= CityNumber;j++){
  cin >> dis;//输入边的信息 
  if(j > i){
  edge[count].from = i;
  edge[count].to = j;
  edge[count++].distance = dis;
  }
  }
 }
    
 for(int i = 1;i <= CityNumber;i++) 
  fat[i] = i;//自己最开始就是自己的老大 （初始化） 
  
 roads = CityNumber * (CityNumber - 1) / 2;
 sort(edge,edge + roads, cmp);//按权值排序（kruskal的体现） 

 for(int i = 0;i < roads;i++)    //从小到大遍历 
 {
  if(HaveBuilt == CityNumber - 1) 
  break;//n个点需要n-1条边连接 
  
  if(father(edge[i].from) != father(edge[i].to))  //假如不在一个团体 
  {
  Union(edge[i].from,edge[i].to);//加入 
  minimum = edge[i].distance;
  HaveBuilt++;//已连接边数+1 
  }
 }
 cout << minimum << endl << endl;
    }
    
    return 0;
}