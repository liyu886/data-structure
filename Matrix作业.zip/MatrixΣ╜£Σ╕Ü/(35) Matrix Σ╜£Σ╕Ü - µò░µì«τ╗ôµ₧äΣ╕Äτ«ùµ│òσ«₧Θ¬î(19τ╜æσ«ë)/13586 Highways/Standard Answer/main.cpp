#include <iostream>
#include <list>
#include <iterator>
using namespace std;
int graph[500][500];
int distotree[500];

void prim(int N, int start){
    int longestpath = 0;
    for(int i = 0; i < N; i++){
        distotree[i] = graph[start][i];
    }
    distotree[start] = 0;
    int process = 1;
    while(process < N){
        int min = 65536;
        int minnodeindex;
        for(int i = 0; i < N; i++){
            if(distotree[i] > 0 && distotree[i] < min){
                min = distotree[i];
                minnodeindex = i;
            }
        }
        distotree[minnodeindex] = 0;
        if(min > longestpath){
            longestpath = min;
        }
        process++;
        //update distance
        for(int i = 0; i < N; i++){
            if(distotree[i] > graph[minnodeindex][i]){
                distotree[i] = graph[minnodeindex][i];
            }
        }
    }
    cout << longestpath << endl;
}
int main() {
    int T;
    int blockcount = 0;
    while(cin >> T){
        while(T--){
            int N;
            cin >> N;
            if(blockcount > 0){
                cout << endl;
            }
            for(int i = 0; i < N; i++){
                for(int j = 0; j < N; j++){
                    cin >> graph[i][j];
                }
            }
            prim(N, 0);
            blockcount++;
        }
    }
    
    return 0;
}
