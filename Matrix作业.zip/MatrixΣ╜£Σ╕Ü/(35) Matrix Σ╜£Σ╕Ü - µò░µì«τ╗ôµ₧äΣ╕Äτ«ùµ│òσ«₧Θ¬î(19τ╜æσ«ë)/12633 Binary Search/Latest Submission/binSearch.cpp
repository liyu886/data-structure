#include "binSearch.h"

int binSearch(const int s[], const int size, const int target){
    int bottom = 0 ;
    int top = size - 1 ;
   
    if ( size == 0)             return -1 ;

    while (bottom <= top){

        int middle = (bottom + top) / 2 ; 

        if (target == s[middle] ) {
            while (target == s[middle+1]){
                ++ middle ;
            }
            return middle ;
        }      

        if (target < s[middle] )        top = middle - 1 ;
           
        if (target > s[middle] )        bottom = middle + 1 ;
            
        
    }
        return -1 ;
}