# ifndef BIN_SEARCH_H
# define BIN_SEARCH_H
int binSearch(const int s[], const int size, const int target);
# endif

