#include <iostream>
#include <queue>
#include "width.h"
using namespace std;




int width(const treeNode* root) {
    if (root == NULL) {
        return 0;
    }
    else {
        int max = 1;
        queue<const treeNode* > q;
        q.push(root);
        const treeNode* a = new treeNode(1, NULL, NULL); //????
        q.push(a);
        while (!q.empty()) {  //???while (1)
            root = q.front();
            q.pop();
            if (q.size() == 0) break; //??????
            if (root == a) {
                q.push(a); //???????push???,??????????????????,??????size-1
                if (q.size() - 1 > max) {
                    max = q.size() - 1;
                }
            }
            else {
                if (root->left != NULL) {
                    q.push(root->left);
                }
                if (root->right != NULL) {
                    q.push(root->right);
                }
            }
        }
        return max;
    }
}