# Width of Binary Trees

## 题目描述
The maximum number of nodes in all levels in a binary tree is called the width of the tree. For example, the binary tree on the right in the following figure has width 4 because the maximum number of nodes is 4 on the third level.   
![](https://bucket-picgo-issac.oss-cn-shenzhen.aliyuncs.com/img/tree1(2).jpg)  
The treeNode is defined as follows.
```cpp
typedef int T;
struct treeNode {
T data;
struct treeNode *left, *right;
treeNode(T d, treeNode *l=NULL, treeNode *r=NULL):data(d),left(l),right(r){};
};
```
Implement the following function that computes the width of a binary tree. 
```cpp
int width(const treeNode * root);
// return the width of the binary tree root.
```