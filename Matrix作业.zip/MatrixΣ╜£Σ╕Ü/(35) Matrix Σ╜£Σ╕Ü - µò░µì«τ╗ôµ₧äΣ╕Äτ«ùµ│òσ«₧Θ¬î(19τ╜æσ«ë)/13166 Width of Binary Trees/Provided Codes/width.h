#ifndef WIDTH_H_INCLUDED
#define WIDTH_H_INCLUDED
#include <cstddef>
using namespace std;
typedef int T;
struct treeNode {
    T data;
    struct treeNode *left, *right;
    
    treeNode(T d, treeNode *l=NULL, treeNode *r=NULL):data(d),left(l),right(r){};
};
int width(const treeNode* root);

#endif // WIDTH_H_INCLUDED