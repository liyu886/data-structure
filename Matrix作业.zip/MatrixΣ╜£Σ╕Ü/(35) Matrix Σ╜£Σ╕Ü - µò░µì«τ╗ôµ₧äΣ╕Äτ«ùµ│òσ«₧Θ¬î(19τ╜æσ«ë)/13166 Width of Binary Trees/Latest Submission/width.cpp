#include <iostream>
#include <queue>
#include"width.h"
using namespace std;

int width(const treeNode* root) {
    if (root == NULL) {
        return 0;
    }
    else {
        int max = 1;
        queue<const treeNode* > q;
        q.push(root);
        const treeNode* a = new treeNode(1, NULL, NULL); //标志结点
        q.push(a);
        while (!q.empty()) {  //可以是while (1)
            root = q.front();
            q.pop();
            if (q.size() == 0) break; //用于跳出循环
            if (root == a) {
                q.push(a); //继续将标志结点push进队列，则此时队列中除标志结点均为同层的结点，该层的宽度为size-1
                if (q.size() - 1 > max) {
                    max = q.size() - 1;
                }
            }
            else {
                if (root->left != NULL) {
                    q.push(root->left);
                }
                if (root->right != NULL) {
                    q.push(root->right);
                }
            }
        }
        return max;
    }
}
