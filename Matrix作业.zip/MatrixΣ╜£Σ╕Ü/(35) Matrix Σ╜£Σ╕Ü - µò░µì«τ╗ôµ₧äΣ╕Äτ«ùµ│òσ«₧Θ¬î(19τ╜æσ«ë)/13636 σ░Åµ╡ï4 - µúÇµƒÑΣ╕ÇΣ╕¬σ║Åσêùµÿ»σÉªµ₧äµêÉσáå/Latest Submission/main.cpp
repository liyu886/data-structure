#include<iostream>
#include<vector>
using namespace std;

bool max(vector<int> arr, int p)
{
    if(2 * p + 1 >= arr.size()) return true;
    if(arr[p] >= arr[2 * p + 1] && 2 * p + 2 >= arr.size()) return true;
    if(arr[p] >= arr[2 * p + 1] && arr[p] >= arr[2 * p + 2]) return max(arr, 2 * p + 1) && max(arr, 2 * p + 2);
    return false;
}

bool min(vector<int> arr, int p)
{
    if(2 * p + 1 >= arr.size()) return true;
    if(arr[p] <= arr[2 * p + 1] && 2 * p + 2 >= arr.size()) return true;
    if(arr[p] <= arr[2 * p + 1] && arr[p] <= arr[2 * p + 2]) return min(arr, 2 * p + 1) && min(arr, 2 * p + 2);
    return false;
}

int main()
{
    int n;
    cin >> n;
    vector<int> arr;
    for(int i = 0; i < n; i ++)
    {
        int a;
        cin >> a;
        arr.push_back(a);
    }
    if(max(arr, 0) == 1 && min(arr, 0) == 0) cout << "max heap" << endl;
    if(max(arr, 0) == 0 && min(arr, 0) == 1) cout << "min heap" << endl;
    if(max(arr, 0) == 0 && min(arr, 0) == 0) cout << "no" << endl;
    if(max(arr, 0) == 1 && min(arr, 0) == 1) cout << "both" << endl;
}