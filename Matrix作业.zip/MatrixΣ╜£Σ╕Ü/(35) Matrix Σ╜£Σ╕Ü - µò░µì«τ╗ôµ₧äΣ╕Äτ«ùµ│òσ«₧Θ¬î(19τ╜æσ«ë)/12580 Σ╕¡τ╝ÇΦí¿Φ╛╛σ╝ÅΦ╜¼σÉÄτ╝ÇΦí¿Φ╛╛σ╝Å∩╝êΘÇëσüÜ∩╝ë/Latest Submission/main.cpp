#include<iostream>
#include<stack>
#include<string>

using namespace std ;

int Priority(const char tmp){
    if (tmp == '+')   return 1 ;
    if (tmp == '-')   return 1 ;
    if (tmp == '*')   return 2 ;
    if (tmp == '/')   return 2 ;
}

int main () {
    stack<char> temp ;
    string str ;

    cin >> str ;

    for (int i = 0 ; i < str.length() ; ++ i){
        if (str[i]>='a' && str[i]<='z' || str[i]>='A' && str[i]<='Z')       cout << str[i] ;
        if (str[i] >= 50 && str[i] <= 55){
            if ( temp.empty() || temp.top() == '(')                         temp.push(str[i]) ;
            if ( Priority( temp.top() ) <= Priority( str[i] ) )             temp.push(str[i]) ;
            if ( Priority( temp.top() ) > Priority( str[i]) ){
                char t = temp.top() ;
                while( temp.empty() != 1 || t !='('){
                    t = temp.top() ;
                    cout << t ;
                    temp.pop() ;
                }
            }
            if ( str[i] == ')'){
                char t =temp.top() ;
                while (  t != '('){
                    cout << t ;
                    temp.pop() ;
                    t = temp.top() ;
                }
                temp.pop() ;   // pop '('
            }
        }
       

        
    }
}