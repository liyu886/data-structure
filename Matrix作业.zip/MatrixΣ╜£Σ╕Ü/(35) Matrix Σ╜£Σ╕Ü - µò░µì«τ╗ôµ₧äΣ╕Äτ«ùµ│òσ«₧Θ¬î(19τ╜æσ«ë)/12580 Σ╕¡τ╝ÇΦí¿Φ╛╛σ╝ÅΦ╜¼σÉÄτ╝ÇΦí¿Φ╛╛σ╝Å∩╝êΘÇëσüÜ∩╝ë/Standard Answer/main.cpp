#include <iostream>
#include <cstring>
#include <stack>
#include <iomanip>
using namespace std;
int main()
{
    int T;
    cin>>T;
    while(T>0){
        string S;
        cin>>S;
        stack<double> rpg;
        for(int i=0;i<S.length();i++){
            if(S[i]>=97&&S[i]<=122){
                double num=S[i]-96;
                rpg.push(num); 
            }
            else if(S[i]==43||S[i]==45||S[i]==42||S[i]==47){
                double num2=rpg.top();
                rpg.pop();
                double num1=rpg.top();
                rpg.pop();
                if(S[i]==43) num1+=num2;
                else if(S[i]==45) num1-=num2;
                else if(S[i]==42) num1*=num2;
                else if(S[i]==47) num1/=num2;
                rpg.push(num1);
            }
        }
        cout<<setprecision(2)<<fixed<<rpg.top()<<endl;
        T--;
    }
}