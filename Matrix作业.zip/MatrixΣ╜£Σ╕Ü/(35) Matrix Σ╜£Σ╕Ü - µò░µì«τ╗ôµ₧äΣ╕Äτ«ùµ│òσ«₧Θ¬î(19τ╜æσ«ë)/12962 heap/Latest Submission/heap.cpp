#include<iostream>
#include"heap.h"

using namespace std;

void heap::push(int input){
    h[++ n] = input;                       
    int pos = n / 2 , last = n;         
    while(pos >= 1){
        if(h[pos] <= h[last]) break;    
        swap(h[pos] , h[last]);            
        last = pos;                        
        pos = pos / 2;
    }
}
void heap::pop(){
    h[1] = h[n --];              
    int pos = 1;                         
    while(1){
        if(2 * pos > n) break;        
        if(2 * pos == n && h[n] >= h[pos]) break;
        if(2 * pos < n && h[pos] <= h[pos * 2 ] && h[pos] <= h[pos * 2 + 1])  
            break;
        if(2 * pos == n && h[n] < h[pos]){
            swap(h[n] , h[pos]);           
            break;
        }
        else                              {
            if(h[pos * 2] < h[pos * 2 + 1]){
                swap(h[pos] , h[pos * 2]); 
                pos = pos * 2;             
            } 
            else{
                swap(h[pos] , h[pos * 2 + 1]);
                pos = pos * 2 + 1;
            }
        }
    }
}
