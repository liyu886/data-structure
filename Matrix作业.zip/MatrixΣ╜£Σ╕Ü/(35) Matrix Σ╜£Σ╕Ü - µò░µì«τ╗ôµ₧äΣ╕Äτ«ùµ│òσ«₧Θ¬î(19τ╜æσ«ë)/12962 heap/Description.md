# heap

## 题目描述
实现一个小根堆用以做优先队列。
给定如下数据类型的定义：
```cpp
class array {
 private:
 int elem[MAXN];
 public:
 int &operator[](int i) { return elem[i]; }
};
class heap {
 private:
 int n;
 array h;
 public:
 void clear() { n = 0; }
 int top() { return h[1]; }
 int size() { return n; }
 void push(int);
 void pop();
};
```
要求实现：
```cpp
void heap::push(int x) {
 // your code
}
void heap::pop() {
 // your code
}
```
## 测试样例
### test code
```cpp
heap h;
h.push(3);
h.push(1);
h.push(2);
printf("%d\n", h.top());
h.pop();
printf("%d\n", h.top());
```
### test output
1  
2  

## 提示
只提交heap::push和heap::pop，注意堆顶元素的下标是1而不是0。