#include "heap.h"
void heap::push(int x) 
{
    int num=n+1;
    int temp=num/2;
    while(temp>=1)
    {
        if(h[temp]<x)break;
        else
        {
            h[num]=h[temp];
            num=temp;
            temp=num/2;
        }
    }
    h[num]=x;
    n++;
}
void heap::pop() 
{
    int low=1;
    int next=low*2;
    int current=h[n];
    while(next<=n-1)
    {
        if(next<n-1&&h[next]>h[next+1])next++;
        if(current<=h[next])break;
        else
        {
            h[low]=h[next];
            low=next;
            next=low*2;
        }
    }
    h[low]=current;
    n--;
}
