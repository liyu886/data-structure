#include<iostream>
#include<cmath>
#include "solve.h"

using namespace std;

long double f(long double x, long double y){
    return exp(x) + log(x) - 1 - y;
}

long double solve(long double y){
    long double mid = 1;
    long double bottom = 0.0;
    long double top = 1000000.0;
    while (f(mid, y) < -pow(10, -6) || f(mid, y) > pow(10, -6)){
        mid = (bottom + top) / 2;
        if (f(mid, y) < 0) bottom = mid;
        else top = mid;
    }
    return mid;
}

