# ifndef SOLVE_H
# define SOLVE_H
long double solve(long double y);
# endif