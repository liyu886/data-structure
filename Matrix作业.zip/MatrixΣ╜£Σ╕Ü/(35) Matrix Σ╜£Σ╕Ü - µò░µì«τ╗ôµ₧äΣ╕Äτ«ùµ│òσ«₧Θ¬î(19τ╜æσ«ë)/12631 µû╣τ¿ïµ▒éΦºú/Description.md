# 方程求解

## 题目描述
已知函数 y = e^x+ln(x)-1，实现函数
```
#include "solve.h"
long double solve(long double y)
{
// here
}
```
对于传入的y，返回x值  
要求f(x)与y的误差小于1e-6，其中 0 < y < 1e10