#ifndef QUERY_H_INCLUDED
#define QUERY_H_INCLUDED
#include <string>
using namespace std;
void query(string A[], int n, string B[], int m);
#endif // QUERY_H_INCLUDED