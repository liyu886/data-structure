# Query

## 题目描述
We have a set of strings (set A) and a set of queries (set B). Each query is to check whether a string exists in set A or not. If yes, output this string.
Your task is to implement the following function:
```cpp
void query(string A[], int n, string B[], int m);
```
Here, n is the number of strings in set A, m is the number of strings in set B. 1<=n,m<=500,000.
Submit the function only.

## 输入描述
No input.
## 输出描述
Output the strings in set B which exist in set A. The output should follow the original order of the strings in set B.
## 提示
For example,
A[0]="ABC", A[1]="CD", A[2]="D"  
B[0] = "A", B[1] ="CD", B[2]="BC", B[3]="ABC",  
then you should output:  
CD  
ABC  