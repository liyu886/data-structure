#include <iostream>
#include <string>
#include <vector>
#include "query.h"

using namespace std;

int p = 500000;
vector <string> T[500001];

int hash_value(const string &A)
{
    int ans = 0;
    for(int i = 0; i < (int)A.size(); ++i)
        ans = (27 * ans + A[i] - 'A' + 1) % p;
        
    return ans;
}

void query(string A[], int n, string B[], int m)
{
    
    int h;
    vector <string>::iterator index;
    for (int i = 0; i <= p; i++)
        T[i].clear();
    for(int i = 0; i < n; i++)
    {
        h = hash_value(A[i]);
        T[h].push_back(A[i]);
    }
    for(int i = 0; i < m; i++)
    {
        h = hash_value(B[i]);
        
            for(index = T[h].begin();index!=T[h].end();index++)
            {
                if (*index == B[i])
                {
                    cout << B[i] <<endl;
                    break;
                }
            }
        
    }
}