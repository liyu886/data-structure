#include <iostream>
#include "query.h"

const int table_size = 1000003;
string hash_table[table_size + 1];

int Hash(const string & key){
    int len = key.size() < 20000 ? key.size() : 20000;  
    int ans = 0 ;    
    const int seed = 131 ;
    for(int i = 0; i < len; i ++){ 
       ans = ( ans * seed ) + ( key[i]  - 'A' + 1 )  ;
       ans = ans % table_size ;
    }
    return ans;
}

void initial_hash_table(string A[], int n){
    for(int i = 0; i < table_size; i ++) hash_table[i] = ""; 
    for(int i = 0; i < n; i ++){
        int key = Hash(A[i]);
        if(hash_table[key].size() == 0) hash_table[key] = A[i];
        else{
            while(hash_table[key].size() != 0) 
            key = (key + 1) % table_size;
            hash_table[key] = A[i];   
        }
    }
}

bool search(const string & value, int key){
    while(hash_table[key].size() != 0){
        if(hash_table[key] == value) return true;
        key = (key + 1) % table_size;
    }
    return false;
}

void query(string A[], int n, string B[], int m){
    initial_hash_table(A, n);                                 
    
    for(int i = 0; i < m; i ++){
        int key = Hash(B[i]);
        if(search(B[i], key)) cout << B[i] << endl;
    }
}
