#include<iostream>
#include "BinaryNode.h"

using namespace std;

int leaves(const BinaryNode* root)
{
    int count = 0;
    if (root == NULL) return 0;
    if (root->left == NULL && root->right == NULL) return 1;
    if (root->left == NULL && root->right != NULL) count += leaves(root->right);
    if (root->left != NULL && root->right == NULL) count += leaves(root->left);
    if (root->left != NULL && root->right != NULL) count += (leaves(root->left) + leaves(root->right));
    return count;
}