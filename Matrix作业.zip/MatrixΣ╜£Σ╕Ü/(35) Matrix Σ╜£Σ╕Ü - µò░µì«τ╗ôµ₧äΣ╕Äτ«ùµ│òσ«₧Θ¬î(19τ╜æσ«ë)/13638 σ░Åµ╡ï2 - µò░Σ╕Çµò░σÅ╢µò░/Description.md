# 小测2 - 数一数叶数

## 问题：
请你实现下列函数，计算给定二叉树的叶数：

```
#include "BinaryNode.h"

int leaves(const BinaryNode* root);
```
