#include <iostream>
#include <vector>
#include <stack>
#include <string>

using namespace std ;

int max(int a , int b ){
    if ( a > b )    return a ;
    else return b ;
}

void clear (stack<char>&a){
    while (a.empty() != 0 ){
        a.pop() ;
    }
}

int longestValidParentheses(string s) {
        int size = s.length();
        vector<int> dp(size, 0);

        int maxVal = 0;
        for(int i = 1; i < size; i++) {
            if (s[i] == ')') {
                if (s[i - 1] == '(') {
                    dp[i] = 2;
                    if (i - 2 >= 0) {
                        dp[i] = dp[i] + dp[i - 2];
                    }
                } else if (dp[i - 1] > 0) {
                    if ((i - dp[i - 1] - 1) >= 0 && s[i - dp[i - 1] - 1] == '(') {
                        dp[i] = dp[i - 1] + 2;
                        if ((i - dp[i - 1] - 2) >= 0) {
                            dp[i] = dp[i] + dp[i - dp[i - 1] - 2];
                        }
                    }
                }
            }
            maxVal = max(maxVal, dp[i]);
        }
        return maxVal;
    }


int main () {
    string s ;
    cin >> s ;
    cout << longestValidParentheses(s) ;
}

