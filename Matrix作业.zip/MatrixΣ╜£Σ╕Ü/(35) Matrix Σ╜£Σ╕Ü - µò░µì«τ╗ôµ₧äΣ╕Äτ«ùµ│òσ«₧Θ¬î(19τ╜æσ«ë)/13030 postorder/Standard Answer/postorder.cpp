#include <iostream>

using namespace std;

int cnt;

void postOrder(int* pre, int* in, int len);

int main()
{
    int n, num;
    cin >> n;
    cnt = n;
    int *preOrder = new int[n];
    int *inOrder = new int[n];  
    for (int i = 0; i < n; ++i) {
        cin >> preOrder[i];
    }
    for (int i = 0; i < n; ++i) {
        cin >> inOrder[i];
    }
    postOrder(inOrder, preOrder, n);
    cout << endl;
    delete[]preOrder;
    delete[]inOrder;
    return 0;
}

void postOrder(int* inOrder, int* preOrder, int len)
{
    if (len == 0)
        return;
    int root = *preOrder;
    int rootIndex = 0;
    for (; rootIndex < len; ++rootIndex) {
        if (inOrder[rootIndex] == *preOrder)
            break;
    }
    postOrder(inOrder, preOrder + 1, rootIndex);
    postOrder(inOrder + rootIndex + 1, preOrder + rootIndex + 1, len - (rootIndex + 1));
    cout << root;
    cnt--;
    if (cnt)
        cout << ' ';
}