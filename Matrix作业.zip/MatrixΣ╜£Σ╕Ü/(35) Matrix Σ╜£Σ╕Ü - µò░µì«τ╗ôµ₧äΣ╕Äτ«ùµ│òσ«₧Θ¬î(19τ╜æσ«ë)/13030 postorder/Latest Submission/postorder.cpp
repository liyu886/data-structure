#include <iostream>
#define MAX_SIZE 100000

void Find_PostOrder(int pre_order[], int in_order[] ,int left, int right, int node_nums) ;
void ReadIn(int nums, int a[]) ;

int main (){
    int nums_node ;
    int pre_order[MAX_SIZE] = {0};
    int in_order[MAX_SIZE]  = {0};
    
    std:: cin >> nums_node ;
    ReadIn(nums_node, pre_order) ;
    ReadIn(nums_node, in_order) ;

    Find_PostOrder(pre_order, in_order, 0, nums_node-1, 0) ;
}

void Find_PostOrder(int pre_order[], int in_order[], int left, int right, int root_position){ 
    if (left > right )              return ;
    int i = 0 ; 
    for (i = left ; i < right ; ++ i) {
        if (pre_order[root_position] == in_order[i] )
        break ;
    }
       
    Find_PostOrder(pre_order, in_order, left, i - 1, root_position+ 1) ;                        // right
    Find_PostOrder(pre_order, in_order, i + 1, right , root_position + 1 + i - left ) ;           //left

    std:: cout << pre_order[root_position] << ' ' ;

}

void ReadIn(int nums, int a[]){
    for (int i = 0 ; i < nums ; ++ i){
        std:: cin >> a[i] ;
    }
}