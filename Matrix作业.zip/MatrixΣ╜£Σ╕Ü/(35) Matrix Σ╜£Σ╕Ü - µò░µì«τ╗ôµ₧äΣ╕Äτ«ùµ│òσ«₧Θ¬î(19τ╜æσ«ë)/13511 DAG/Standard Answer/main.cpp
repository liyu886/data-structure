#include<iostream>
#include<cstring>
using namespace std;

int n,c,a[100][100],visited[100],is;  
int dfs(int v)
{      
    visited[v] = -1;      
    for(int i = 1; i <= n; i++)      
    {          
        if(a[v][i] != 0 && !visited[i])  {            
            dfs(i);          
            visited[i]=1;  
        }  
        if(a[v][i] != 0 && visited[i] == -1){       
            cout<<0<<endl;  
            is=true;
        }  
    }
}  
int main(){  
    memset(a,0,sizeof(a));  
    memset(visited,0,sizeof(visited));  
    is=0;
    cin>>n>>c;
    int r1,r2;
    for(int i=0;i<c;++i){
        cin>>r1>>r2;
        a[r1][r2]=1;
    }
    dfs(1);
    if(!is)
        cout<<1<<endl;
}