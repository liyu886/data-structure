#include<iostream>
#include<queue>
using namespace std;

int main()
{
    int n, m, u, v, i, j, count, fro;
    int check[105] = {0};
    int matrix[105][105];
    queue<int>q;

    cin >> n >> m;
    count = n;

    for(i = 0; i <= n; i++){
        for(j = 0; j < n; j ++){
            matrix[i][j] = 0;
        }
    }

    while( m-- ){
        cin >> u >> v;
        matrix[u][v] = 1;
    }

    while( count > 0 ){
        int indegree[105] = {0};
        for(i = 1; i <= n; i++){
            if(check[i] == 0){
                for(j = 1; j <= n; j++){
                indegree[i] += matrix[j][i];
                }
                if(indegree[i] == 0){
                    q.push(i);
                    check[i] = 1;
                    count--;
                }
            }
        }
        if(q.empty() == 1){
            cout << 0 << endl;
            return 0;
        }
        while(q.empty() == 0){
            fro = q.front();
            q.pop();
            for(j = 1; j <= n; j++){
                matrix[fro][j] = 0;
        }
        }
    }
    cout << 1 << endl;
}