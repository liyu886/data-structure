#include<bits/stdc++.h>
using namespace std;
int main()
{
    int num[10];
    for(int i = 0 ; i< 10 ; i++)
    {
        cin >> num[i];
    }
    int target = 0;
    cin >> target;
    for(int i =0 ;i<10;i++)
    for(int j =0 ;j<10;j++)
    {
        if(num[i]+num[j]==target)
        {
            printf("%d %d",i,j);
            return 0;
        }
    }
}