#include<stdio.h>
#include<stdlib.h>
#include<iostream>
#include<string>
#include <deque>
#include <queue>

using namespace std;
 
typedef struct Node
{
    int key;
    struct Node *left;
    struct Node *right;
    int height;
}BTNode;
 
int max(int a, int b);
 
 
int height(struct Node *N)
{
    if (N == NULL)
        return 0;
    return N->height;
}
 
int max(int a, int b)
{
    return (a > b) ? a : b;
}
 
BTNode* newNode(int key)
{
    struct Node* node = (BTNode*)malloc(sizeof(struct Node));
    node->key = key;
    node->left = NULL;
    node->right = NULL;
    node->height = 1;
    return(node);
}
 
BTNode* ll_rotate(BTNode* y)
{
    BTNode *x = y->left;
    y->left = x->right;
    x->right = y;
 
    y->height = max(height(y->left), height(y->right)) + 1;
    x->height = max(height(x->left), height(x->right)) + 1;
 
    return x;
}
 
BTNode* rr_rotate(BTNode* y)
{
    BTNode *x = y->right;
    y->right = x->left;
    x->left = y;
 
    y->height = max(height(y->left), height(y->right)) + 1;
    x->height = max(height(x->left), height(x->right)) + 1;
 
    return x;
}
 
int getBalance(BTNode* N)
{
    if (N == NULL)
        return 0;
    return height(N->left) - height(N->right);
}
 
BTNode* insert(BTNode* node, int key)
{
 
    if (node == NULL)
        return newNode(key);
 
    if (key < node->key)
        node->left = insert(node->left, key);
    else if (key > node->key)
        node->right = insert(node->right, key);
    else
        return node;
 
    node->height = 1 + max(height(node->left), height(node->right));
 
 
    int balance = getBalance(node);
 
 
 
    if (balance > 1 && key < node->left->key)
        return ll_rotate(node);
 
 
    if (balance < -1 && key > node->right->key)
        return rr_rotate(node);
 
 
    if (balance > 1 && key > node->left->key)  
    {
        node->left = rr_rotate(node->left);
        return ll_rotate(node);
    }
 
    if (balance < -1 && key < node->right->key)
    {
        node->right = ll_rotate(node->right);
        return rr_rotate(node);
    }
 
    return node;
}
 
 
void Order(Node *root){
	queue<Node*> q;
	Node *front;
	if(root == NULL) return;
	q.push(root);
	while(!q.empty()){
		front = q.front();
		q.pop();
		if(front->left) q.push(front->left);
		if(front->right) q.push(front->right);
		cout << front->key<< " ";
	}
}
 
int main()
{
    
	int n=0;
	cin>>n;
	BTNode *root = NULL;
 for(int i=0;i<n;i++){
 	int temp;
 	cin>>temp;
 	root = insert(root, temp);
 }
    Order(root);
    return 0;
}
