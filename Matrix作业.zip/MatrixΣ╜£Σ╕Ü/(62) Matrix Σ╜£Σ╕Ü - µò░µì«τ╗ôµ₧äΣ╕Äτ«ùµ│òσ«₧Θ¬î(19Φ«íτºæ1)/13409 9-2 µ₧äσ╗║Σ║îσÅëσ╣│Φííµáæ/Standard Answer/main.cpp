#include <algorithm>
#include <iostream>
#include <queue>
using namespace std;
class Node {
public:
	int val;
	int height;
	Node* left;
	Node* right;
};
int height(Node* n) {
	if (n == nullptr) return 0;
	return n->height;
}
Node* LLrot(Node* A) {
	Node* B = A->left;
	A->left = B->right;
	B->right = A;
	A->height = max(height(A->left), height(A->right)) + 1;
	B->height = max(height(B->left), A->height) + 1;
	return B;
}
Node* RRrot(Node* A) {
	Node* B = A->right;
	A->right = B->left;
	B->left = A;
	A->height = max(height(A->left),height(A->right))+1;
	B->height = max(height(B->right), A->height) + 1;
	return B;
}
Node* LRrot(Node*A) {
	A->left = RRrot(A->left);
	return LLrot(A);
}
Node* RLrot(Node*A) {
	A->right = LLrot(A->right);
	return RRrot(A);
}
Node* insert(Node* root, int key) {
	if (root == nullptr) {
		root = new Node();
		root->val = key;
		root->height = 1;
	}
	else if (key < root->val) {
		root->left = insert(root->left, key);
		if (height(root->left) - height(root->right) == 2) {
			if (key < root->left->val) {
				root = LLrot(root);
			}
			else {
				root = LRrot(root);
			}
		}
	}
	else if (key > root->val) {
		root->right = insert(root->right, key);
		if (height(root->right) - height(root->left) == 2) {
			if (key > root->right->val) {
				root = RRrot(root);
			}
			else {
				root = RLrot(root);
			}
		}
	}
	root->height = max(height(root->left), height(root->right)) + 1;
	return root;
}
void printTree(Node* root) {
	Node* t = root;
	queue<Node*> q;
	if (t != nullptr) {
		q.push(t);
	}
	while (!q.empty()) {
		t = q.front();
		q.pop();
		cout << t->val <<" ";
		if (t->left != nullptr) {
			q.push(t->left);
		}
		if (t->right != nullptr) {
			q.push(t->right);
		}
	}
}
int main() {
	Node* root=nullptr;
	int k;
	cin >> k;
	for (int i = 0; i < k; i++) {
		int t;
		cin >> t;
		root = insert(root, t);
	}
	printTree(root);
	return 0;
}