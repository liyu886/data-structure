#include<bits/stdc++.h>
using namespace std;
int main()
{
    int size;
    cin >> size;
    for(int i = 0; i < size ;i++)
    {
        int n;
        cin >> n;
        int check[1000];
        for(int i = 0;i <n ;i++)
        {
        	int size;
        	cin >> size;
		}
		for(int i = 0;i <n ;i++)
        {
        	cin >> check[i];
		}
		int ok = 1;
		for(int i = 0;i < n - 1 ;i++)
        {
        	if(check[i] > check[i+1])
        	{
        		cout << "No" << endl;
        		ok = 0;
        		break;
			}
		}
		if(ok) cout << "Yes" << endl;
    }
}