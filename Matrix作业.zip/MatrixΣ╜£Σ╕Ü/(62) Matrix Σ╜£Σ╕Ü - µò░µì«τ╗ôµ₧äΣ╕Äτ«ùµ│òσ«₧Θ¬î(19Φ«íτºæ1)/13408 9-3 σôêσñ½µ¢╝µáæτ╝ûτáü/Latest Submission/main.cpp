#include<iostream>
using namespace std;
class haf{
	public:
		char a;
		int b;
};
class sen{
	public:
		char name;
		int data;
		int parent;
		int lchild;
		int rchild;
};
haf p[100000];
sen ht[100000];
	int k;
void print(int i)
{
	if(i<=k)
	{
		cout<<ht[i].name<<endl;
	}
	if(ht[i].lchild!=0)
	print(ht[i].lchild);
	if(ht[i].rchild!=0)
	print(ht[i].rchild);
}

void select(int l,int &s1,int &s2)
{
	int i,temp;
	int max1=1000000;
	int max2=1000000;
	for(i=1;i<=l;i++)
	{
		if(ht[i].parent==0&&ht[i].data<max2)
		{
			max2=ht[i].data;
			s2=i;
		}
		if(max2<max1)
		{
			temp=s2;
			s2=s1;
			s1=temp;
			temp=max1;
			max1=max2;
			max2=temp;
		}
	}
}
int main()
{

	cin>>k;
	int i;
	 int s1=0;
	 int s2=0;
	for(i=0;i<k;i++)
	{
		cin>>p[i].a;
		cin>>p[i].b;
	}
	
	for(i=1;i<=k;i++)
	{
		ht[i].name=p[i-1].a;
		ht[i].data=p[i-1].b;
		ht[i].parent=0;
		ht[i].lchild=0;
		ht[i].rchild=0;
	}
	for(i=k+1;i<=2*k-1;i++)
	{
		select(i-1,s1,s2);
		ht[s1].parent=i;
		ht[s2].parent=i;
		ht[i].lchild=s2;
		ht[i].rchild=s1;
		ht[i].parent=0;
		ht[i].data=ht[s1].data+ht[s2].data;
	}
	
	print(2*k-1);
}