#include <iostream>
#include <vector>
#include <string>
#include <queue>
using namespace std;

class Node {
public:
	int freq;
	char key;
	Node* left;
	Node* right;
	Node() {}
	Node(int freq_, char key_) :freq(freq_), key(key_) { }
};
class cmp {
public:
	bool operator() (Node*a, Node*b) {
		return a->freq > b->freq;
	}
};
Node* build(Node* data[], int len) {
	priority_queue<Node*, vector<Node*>, cmp> q;
	for (int i = 0; i < len; i++) {
		q.push(data[i]);
	}
	while (q.size()>=2) {
		Node* t1 = q.top();
		q.pop();
		Node* t2 = q.top();
		q.pop();
		Node* t = new Node();
		// 两个节点合并的顺序，频率小的放右边，频率大的放左边，频率一样字符小的右边，字符大的左边。
		if (t1->freq < t2->freq) {
			t->right = t1;
			t->left = t2;
		}
		else if (t1->freq == t2->freq) {
			if (t1->key < t2->key) {
				t->right = t1;
				t->left = t2;
			}
			else {
				t->left = t1;
				t->right = t2;
			}
		}
		else {
			t->left = t1;
			t->right = t2;
		}
		t->freq = t1->freq + t2->freq;
		q.push(t);
	}
	Node* root = q.top();
	return root;
}

void printcode(Node* root) {
	Node* t = root;
	if (t->left != nullptr) {
		printcode(t->left);
	}
	if (t->right != nullptr) {
		printcode(t->right);
	}
	if (t->left == nullptr&&t->right == nullptr) {
		cout << t->key << endl;
	}
}
int main() {
	int k;
	cin >> k;
	char val;
	int freq;
	Node* root;
	Node* data[100];
	for (int i = 0; i < k; i++) {
		cin >> val >> freq;
		data[i] = new Node(freq, val);
	}
	root = build(data,k);
	printcode(root);
	return 0;
}
/*
7
A 5
F 5
C 7
G 13
E 34
B 24
D 17
*/
/*
E 00
D 010
G 011
B 10
F 1100
A 1101
C 111
*/