#include <iostream>
#include <queue>
#define MAXN 30000

using namespace std;

struct flight {
    int cost, dt;
    bool operator< (const flight a) const {
        return cost < a.cost;
    }
}fl[MAXN+1];

int main () {
    int n, k;
    priority_queue<flight> q;
    cin >> n >> k;
    for (int i = 1; i <= n; i++) {
        cin >> fl[i].cost;
        fl[i].dt = i;
    }
    long long sum = 0;
    for (int i = 1; i <= k; i++) {
        q.push(fl[i]);
    }
    for (int i = k+1; i <= k+n; i++) {
        if (i <= n) {
            q.push(fl[i]);
        }
        flight a = q.top();
        q.pop();
        sum += (long long)(i-a.dt)*a.cost;
    }
    cout << sum << endl;
    return 0;
}

