#include<bits/stdc++.h>
using namespace std;
struct node
{
    int id;
    int cost;
    bool operator <(const node & other) const
    {
    return cost < other.cost;
    }
}p[100000];
int main()
{
    int n,k;
    cin >> n >> k;
    long long total = 0;
    for(int i = 1; i <= n ;i++)
    {
        cin >> p[i].cost;
        p[i].id = i;
    }
    priority_queue<node>q;
    for(int i= 1; i <= k;i++)
    q.push(p[i]);
    for(int i= k+1;i <= k+n;i++)
    {
        if(i<=n)
        q.push(p[i]);
        node temp = q.top();
        q.pop();
        total += temp.cost * (i-temp.id);
    }
    cout << total << endl;
}