#include<bits/stdc++.h>
using namespace std;
vector<int > g[1000];
int A[1000];
void dfs(int x,int d)
{
    if(A[x]) return;
    A[x] = d;
    for(int i = 0; i < g[x].size();i++)
    dfs(g[x][i],d);
}
int main()
{
    int n, m;
    cin >> n >> m;
    for(int i = 1 ; i <= m;i++)
    {
        int a,b;
        cin >> a>>b;
        g[b].push_back(a);
    }
    for(int i = n ;i ;i--)
    dfs(i,i);
    for(int i = 1 ;i <= n;i++)
    cout << A[i] << " ";
    return 0;
}