#include<bits/stdc++.h>
using namespace std;
typedef struct node
{
    int num;
    node * left;
    node * right;
};
void newnode(node * &root,int v)
{
    root = new node;
    root->num = v;
    root->left = root->right = NULL;
}
void insert(node * &root,int v)
{
    if(root == NULL)
    newnode(root,v);
    if(root->num == v) return;
    else if(root->num > v)
    insert(root->left,v);
    else insert(root->right,v);
}
int ok;
void pd(node *root)
{
    if(root == NULL) return;
    if(root->left==NULL&&root->right!=NULL)
    ok = 0;
    if(root->left!=NULL&&root->right==NULL)
    ok = 0;
    pd(root->left);
    pd(root->right);
}
int main()
{
    int t;
    cin >> t;
    for(int i = 0; i < t ;i++)
    {
        int n;
        cin >> n;
        node * root = NULL;
        if(n == 0)
        {
            cout <<"NO\n";
            continue;
        }
        for(int j = 0; j < n ;j++)
        {
            int temp;
            cin >> temp;
            insert(root,temp);
        }
        ok = 1;
        pd(root);
        if(ok) cout << "YES\n";
        else cout <<"NO\n";
    }
}