#include<bits/stdc++.h>
using namespace std;
int main()
{
    string temp;
    cin >> temp;
    int num[200];
    memset(num, 0, sizeof(num));
    int ans = 0;
    if(temp.length() == 1)
    {
        cout << 1;
        return 0;
    }
    for(int i = 0; i < temp.length();i++)
    {
        int j = i + 1;
        memset(num, 0, sizeof(num));
        num[temp[i]]++;
        while(j<temp.length())
        {
            if(!num[temp[j]])
            {
                num[temp[j]]++;
                j++;
            }
            else
            {
                break;
            }
        }
        ans = max(ans,j-i);
    }
    cout << ans <<endl;
}