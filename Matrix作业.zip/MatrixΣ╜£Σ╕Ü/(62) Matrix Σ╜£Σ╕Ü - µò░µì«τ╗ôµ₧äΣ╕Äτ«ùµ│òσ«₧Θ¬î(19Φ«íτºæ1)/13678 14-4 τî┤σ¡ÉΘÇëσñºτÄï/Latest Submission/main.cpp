#include<bits/stdc++.h>
using namespace std;
long long f[1000];
long long num[1000];

int main() 
{
    int t;
    cin >> t;
    for(int i = 0; i < t; i++)
    {
        int n ,m;
        cin >> n >> m;
        int count = 0;
        int a[n+1];
        a[0] = 0;
        for(int j = 1; j < n+1 ; j++)
        a[j] = j;
        int now = 1;
        int p = 1;
        while(count + 1 != n)
        {
            if(a[p] != -1)
            {
                if(now == m)
                {
                    a[p] = -1;
                    count++;
                    now = 0;
                }
                now = now + 1;
                p = p % n + 1;
            }
            else
            {
                p = p % n + 1;
            }
        } 
        for(int j = 1; j < n+1 ; j++)
        if(a[j] != -1) cout << j <<endl;
    }
}