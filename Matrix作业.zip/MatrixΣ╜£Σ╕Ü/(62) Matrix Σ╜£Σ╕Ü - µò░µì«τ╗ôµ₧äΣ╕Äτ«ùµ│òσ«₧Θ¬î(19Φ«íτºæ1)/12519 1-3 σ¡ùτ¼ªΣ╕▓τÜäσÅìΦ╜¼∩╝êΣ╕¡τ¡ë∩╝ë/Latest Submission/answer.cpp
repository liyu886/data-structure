#include<bits/stdc++.h>
using namespace std;
int main()
{
    string a;
    char b[1000];
    getline(cin,a);
    int i=0,s=0;
    char temp;
    while(1)
    {
        if(a[s] != ' ')
        {
            b[i++] = a[s++];
        }
        else
        {
            for(int j =i-1;j>=0;j--)
            {
                cout<<b[j];
            }
            cout<<" ";
            i = 0;
            s++;
        }
        if(s == a.length())
		{
			for(int j =i-1;j>=0;j--)
            {
                cout<<b[j];
            }
            return 0;
		}
    }
}