#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n,k;
    cin>>n>>k;
    int a[n+1],b[n];
    for(int i =0; i<n ;i++)
    {
        cin>>a[i];
    }
    b[0] = 0;
    for(int i =1;i<n;i++)
    b[i] = b[i-1]+a[i-1];
    int maxx1 = 0,id1= 0;
    int maxr = 0;
    int ans[3];
    for(int id1=k;id1<=n-1-k*2;id1++)
    {
    int maxx2 = 0,id2= 0;
    int maxx3 = 0,id3= 0;
    for(int i=0;i<=id1-k;i++)
    {
        if(b[i+k]-b[i]>maxx2)
        {
            id2 = i;
            maxx2 = b[i+k]-b[i];
        }
    }
    for(int i=id1+k;i<=n-1-k;i++)
    {
        if(b[i+k]-b[i]>maxx3)
        {
            id3 = i;
            maxx3 = b[i+k]-b[i];
        }
    }
    if(b[id1+k]-b[id1]+maxx1+maxx3>maxr)
    {
        maxr = b[id1+k]-b[id1]+maxx1+maxx3;
        ans[0] = id2;
        ans[1] = id1;
        ans[2] = id3;
    }
    }
    printf("%d,%d,%d",ans[0],ans[1],ans[2]);
}