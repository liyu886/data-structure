#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a[1000] ={0};
    int num = 0;
    while(cin>>a[num])
    {
        num++;
    }
    int i = 0 ,j = 1;
    int ans = 0;
    while(j < num)
    {
        if(a[i]!=a[j])
        {
            a[++i] = a[j];
            ans++;
        }
        j++;
    }   
    cout << ans + 1 << endl;
}