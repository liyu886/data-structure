#include<bits/stdc++.h>
using namespace std;
int main()
{
    int s,n;
    cin>>s>>n;
    int a[n],b[n];
    int sum =0;
    for(int i =0 ;i<n;i++)
    {
        cin >>a[i];
        sum+= a[i];
        b[i] = sum;
    }
    int ans = 100000;
    for(int i =0;i<n;i++)
    for(int j=i+1;j<n;j++)
    {
        if(b[j]-b[i]>=s)
        {
            ans = min(ans,j-i);
        }
    }
    cout<<ans<<endl;
}