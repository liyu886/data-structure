#include<bits/stdc++.h>
using namespace std;
bool cmp(int a,int b)
{
   return a > b;
}
int main()
{
   int n,m;
   cin >> n >> m;
   priority_queue<int,vector<int>,greater<int> >q1,q2;
   q1.push(1);
   while(q2.size()<n)
   {
      q1.push(q1.top()*2+1);
      q1.push(q1.top()*4+5);
      q2.push(q1.top());
      q1.pop();
   }
   string ans;
   int t = 0;
   while(t < n)
   {
      stringstream ss;
       ss<<q2.top();
      ans+=ss.str();
      q2.pop();
      t++;
   }
    string ans1 = ans;
    int t1 = 0;
    char temp[2000];
    int top =0;
    for(int i = 1; i < ans1.size(); i++)
    {
        while(top>0&&m>1&&ans1[i]>temp[top-1])
        {
            top--;
            temp[top]=ans1[i];
            m--;
        }
    temp[top++]=ans1[i];
    }
   cout << ans << endl;
   for(int i =0 ;i < top; i++)
   cout<<temp[i];
}