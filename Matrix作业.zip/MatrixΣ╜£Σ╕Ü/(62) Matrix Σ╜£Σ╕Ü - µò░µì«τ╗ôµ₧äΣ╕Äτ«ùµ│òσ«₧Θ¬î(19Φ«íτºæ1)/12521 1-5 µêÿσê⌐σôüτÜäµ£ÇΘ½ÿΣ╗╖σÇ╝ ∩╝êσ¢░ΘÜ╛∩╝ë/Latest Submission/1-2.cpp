#include<bits/stdc++.h>
using namespace std;
int t[4][4];
int ans = 0;
void dfs(int a,int b,int value)
{
    if(a==3&&b==3)
    {
        if(value> ans)
        ans = value;
    }
    if(a<3) dfs(a+1,b,value+t[a+1][b]);
    if(b<3) dfs(a,b+1,value+t[a][b+1]);

}
int main()
{
    for(int i =0 ; i<4;i++)
    for(int j =0 ; j<4;j++)
    {
        cin >> t[i][j];
    }
    dfs(0,0,0);
    ans+=t[0][0];
    cout << ans;
}