#include<bits/stdc++.h>
using namespace std;
int vis[1000];
vector<int> a[1000];
int n,m;
int num1;
int num2;
void DFS(int s);
bool tree()
{
    num1 = num2 = 0;
    DFS(1);
    if(num1 == n&&num2==2*(n-1))
    cout << "YES\n";
    else cout << "NO\n";
}
void DFS(int s)
{
    if(!vis[s])
    {
        vis[s] = 1;
        num1++;
        for(int i = 0;i < a[s].size();i++)
        {
            num2++;
            int v = a[s][i];
            if(!vis[v])
            {
                DFS(v);
            }
        }
    }
}
int main()
{
    int t;
    cin >> t;
    for(int i = 0; i < t;i++)
    {
        cin >> n >> m;
        memset(a,0,sizeof(a));
        memset(vis,0,sizeof(vis));
        for(int j = 0; j < m;j++)
        {
            int u,v;
            cin >> u >> v;
            a[u].push_back(v);
            a[v].push_back(u);
        }
        tree();
    }
}