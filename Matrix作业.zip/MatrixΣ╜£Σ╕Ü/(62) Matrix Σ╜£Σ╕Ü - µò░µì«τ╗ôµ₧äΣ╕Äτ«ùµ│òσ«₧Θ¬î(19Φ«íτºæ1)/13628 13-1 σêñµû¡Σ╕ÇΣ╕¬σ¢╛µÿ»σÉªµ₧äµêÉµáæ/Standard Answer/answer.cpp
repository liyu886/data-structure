#include <iostream>
#include <vector>
#include <stack>

using namespace std;
typedef vector<vector<int> > Graph;
typedef int Vertex;


//vertices are named as 1, 2, ...,n, but internally 0,1,2,..., n-1.
//DFS starting from s



void DFS_rec(Graph g, vector<bool> &visited, Vertex s, bool & hasCircle, vector<Vertex> &parent){
       size_t k = g[s].size();
       visited[s] = true;
       for (size_t j=0;j<k;j++){
          Vertex u = g[s][j];
          if (!visited[u]){
            parent[u] = s;
            DFS_rec(g, visited, u, hasCircle,parent);
          }
          else if (parent[s]!= u && parent[u] != s)
              hasCircle = true;            
          
       }
}

bool allVisited(const vector<bool>& visited){
  for (size_t i=0;i<visited.size();i++){
     if (!visited[i])
       return false;
  }
  return true;
}


bool isTree(const Graph & g){
    Vertex s = 0;
    size_t n = g.size();
    vector<bool> visited(n,false);
    vector<Vertex> parent(n,-1);
    bool hasCircle = false;
    DFS_rec(g,visited,s,hasCircle,parent);
    bool b = allVisited(visited);
    if (hasCircle || !b ){
/*
       if (hasCircle)
          cout<<"has circle"<<endl;
       if (!b)
          cout <<"not connected"<<endl;
*/
       return false;
    }
    else
       return true;
} 


void print(Graph g){
  for (size_t i=0;i<g.size();i++){
    cout <<i+1<<":";
    for (size_t j=0;j<g[i].size();j++)
      cout <<g[i][j]+1<<" ";
    cout <<endl;
  }
}
Graph mkGraph(){
  int m,n,u,v;
  cin >>n>>m;
  Graph g;
  g.resize(n);
  for (int i=0;i<m; i++){
     cin>>u>>v;
     g[u-1].push_back(v-1);
     g[v-1].push_back(u-1);
   }
  return g;
}


int main(int argc, char* argv[]){
    int k,m,n;
    cin >> k;
    while (k--){
       Graph g;
//print(g);
       g = mkGraph();
//print(g);       

    bool b = isTree(g);
//cout<<r<<endl;
       if (b)
         cout <<"YES"<<endl;   
       else
         cout <<"NO"<<endl;
    }

    return 0;
}


