#include "helper.h"
Node* FindKthBigElementInTwoList(Node* List1, Node* List2, int k);
