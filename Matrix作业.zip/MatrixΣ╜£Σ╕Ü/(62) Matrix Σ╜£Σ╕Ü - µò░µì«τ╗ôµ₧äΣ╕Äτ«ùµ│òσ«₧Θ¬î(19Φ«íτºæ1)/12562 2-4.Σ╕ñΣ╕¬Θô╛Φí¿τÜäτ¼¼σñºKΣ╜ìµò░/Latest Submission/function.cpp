#include"function.h"
Node* FindKthBigElementInTwoList(Node* List1, Node* List2, int k)
{
    Node * curr1 = List1;
    Node * curr2 = List2;
    int t = 0;
    int a[1000];
    while(curr1 != NULL)
    {
        a[t++] = curr1->value;
        curr1 = curr1->next;
    }
    while(curr2 != NULL)
    {
        a[t++] = curr2->value;
        curr2 = curr2->next;
    }
    for(int i =0;i<t;i++)
    for(int j =0;j<t;j++)
    {
        if(a[i]>a[j])
        {
            int t = a[j];
            a[j] = a[i];
            a[i] = t;
        }
    }
    curr1 = List1;
    curr2 = List2;
    while(curr1 != NULL)
    {
        if(curr1->value == a[k-1])
        return curr1;
        curr1 = curr1->next;
    }
    while(curr2 != NULL)
    {
        if(curr2->value == a[k-1])
        return curr2;
        curr2 = curr2->next;
    }
}