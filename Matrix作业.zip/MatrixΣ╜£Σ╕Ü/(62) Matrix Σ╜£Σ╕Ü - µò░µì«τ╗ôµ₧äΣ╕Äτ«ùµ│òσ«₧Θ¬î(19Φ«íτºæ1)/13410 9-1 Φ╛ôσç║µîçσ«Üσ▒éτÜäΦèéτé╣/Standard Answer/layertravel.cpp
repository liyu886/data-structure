
#include <iostream>
#include <vector>
#include <random>
#include <queue>
#include <stdlib.h>
#include <time.h>
using namespace std;

class Node {
public:
	int val;
	Node* left;
	Node* right;
};
void buildtree(int a[], int n, Node** root, int i) {
	if (i < n) {
		*root = new Node();
		(*root)->val = a[i];
		buildtree(a, n, &(*root)->left, i * 2 + 1);
		buildtree(a, n, &(*root)->right, (i + 1) * 2);
	}
}
void printqueue(queue<Node*> q) {
	while (!q.empty()) {
		cout << q.front()->val << " ";
		q.pop();
	}
	cout << endl;
}
void printlevel(Node* root, int n) {
	if (root == nullptr) {
		return;
	}
	else {
		int count_levels, count_nodes, level_nodes;
		Node* t;
		queue<Node*> q;
		q.push(root);
		count_levels = 1;
		while (!q.empty()) {
			if (count_levels == n) {
				break;
			}
			count_nodes = 0;
			level_nodes = q.size();
			while (count_nodes < level_nodes) {
				t = q.front();
				q.pop();
				if (t->left != nullptr) {
					q.push(t->left);
				}
				if (t->right != nullptr) {
					q.push(t->right);
				}
				count_nodes += 1;
			}
			count_levels += 1;
		}
		printqueue(q);
	}

}

int main() {
	Node* root;
	int array[1000];
	int k, n;
	cin >> k >> n;
	for (int i = 0; i < k; i++) {
		cin >> array[i];
	}
	buildtree(array,10,&root,0);
	printlevel(root, n);
	return 0;
}
