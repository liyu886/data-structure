#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n, d;
    cin>> n>> d;
    int a[n];
    for(int i = 0; i < n;i++)
    cin >> a[i];
    int ans = 0;
    for(int i = 0;i<n-2;i++)
    for(int j = i+2;j<n;j++)
    {
        if(a[j]-a[i]>d)
        break;
        else
        ans += j-i-1;
    }
    cout << ans << endl;
}