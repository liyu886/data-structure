#include <iostream>
#include <queue>
typedef long long LL;

using namespace std;

queue<LL> q;
int main() {
    int n;
    LL x, cnt = 0, ans = 0, d;
    cin >> n >> d;
    for (int i = 0; i < n; i++) {
        cin >> x;
        q.push(x);
        cnt++;
        while (x-q.front()>d) {
            q.pop();
            cnt--;
        }
        ans += (cnt-1)*(cnt-2)/2;
    }
    cout << ans << endl;
    return 0;
}