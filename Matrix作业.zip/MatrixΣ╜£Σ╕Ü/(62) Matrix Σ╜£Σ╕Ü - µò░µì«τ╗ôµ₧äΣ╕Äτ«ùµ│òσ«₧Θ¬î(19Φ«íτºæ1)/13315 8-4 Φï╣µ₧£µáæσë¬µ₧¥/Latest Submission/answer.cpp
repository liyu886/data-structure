#include<iostream>
#define N 2000
using namespace std;
int head[N]={0};
int nex[N]={0};
int V[N]={0};
int W[N]={0};
int num[N]={0};
int tot=0;
int n=0,m=0;
int dp[N][N]={0};
void add(int x,int y,int c){
	tot++;
	nex[tot]=head[x];V[tot]=y;W[tot]=c;
	head[x]=tot; 
}
void DP(int root,int fa){
	num[root]++;
	for(int i=head[root];i;i=nex[i]){
		int v=V[i],w=W[i];
		if(v==fa) continue;
		DP(v,root);
		for(int i=num[root]-1;i>=0;i--){
			for(int j=num[v]-1;j>=0;j--){
				dp[root][i+j+1]=max(dp[root][i+j+1],dp[root][i]+dp[v][j]+w);
			}
		}
		num[root]+=num[v]; 
	}
}
int main(){
	cin>>n>>m;
	for(int i=1,a,b,c;i<n;i++){
		cin>>a>>b>>c;
		add(a,b,c);add(b,a,c);
	}
	DP(1,-1);
	cout<<dp[1][m]<<endl;
	return 0;
} 
