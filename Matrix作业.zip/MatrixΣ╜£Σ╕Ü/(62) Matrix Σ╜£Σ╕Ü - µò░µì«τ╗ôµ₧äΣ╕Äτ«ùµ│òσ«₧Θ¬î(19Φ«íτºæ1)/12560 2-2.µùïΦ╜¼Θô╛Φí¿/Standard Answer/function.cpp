#include "function.h"
/*
4
1 2 3 4 5 6 7 8 9 10
*/
Node* RotateList(Node* head, int k) {
    int cnt = k-1;
    Node* mid = head;
    Node* mid_parent = mid;
    while (cnt>0) {
        cnt--;
        mid_parent = mid;
        mid = mid->next;
    }
    mid_parent->next = nullptr;
    Node* right = ReverseList(mid->next);
    GetLastNode(right)->next = mid;
    mid->next = head;
    return right;
}
