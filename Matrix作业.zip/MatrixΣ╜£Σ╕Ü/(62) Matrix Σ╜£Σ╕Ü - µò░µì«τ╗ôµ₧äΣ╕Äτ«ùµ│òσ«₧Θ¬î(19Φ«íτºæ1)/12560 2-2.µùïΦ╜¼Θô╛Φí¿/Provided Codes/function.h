#include "helper.h"
Node* RotateList(Node* head, int k);