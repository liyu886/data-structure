#include"function.h"
Node* RotateList(Node* head, int k)
{
    Node *curr = head;
    int a[1000];
    int t = 0;
    while(curr != NULL)
    {
        a[t++] = curr->value;
        curr = curr->next;
    }
    curr = head;
    for(int i = t-1;i>=k;i--)
    {
        curr->value = a[i];
        curr = curr->next;
    }
    curr->value = a[k-1];
    curr = curr->next;
    for(int i = 0;i<k-1;i++)
    {
        curr->value = a[i];
        curr = curr->next;
    }
    return head;
}