#include<bits/stdc++.h>
using namespace std;
priority_queue<int,vector<int>,greater<int> >a;
int main()
{
    int n;
    cin >> n;
    for(int i = 1;i <= n;i++)
    {
        int temp;
        cin >> temp;
        a.push(temp);
    }
    int ans = 0;
    for(int i = 0 ; i < n-1 ;i++)
    {
        int alua = a.top();
        a.pop();
        int alub = a.top();
        a.pop();
        int c = alua + alub;
        a.push(c);
        ans += c;
    }
    cout << ans;
}