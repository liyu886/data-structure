#include<bits/stdc++.h>
using namespace std;
stack<char> f1;
stack <int> f2;
int getIndex(char temp)
{  
    int index = 0;  
    switch (temp)  
    {  
    case '+':  
        index = 0;  
        break;  
    case '-':  
        index = 1;  
        break;  
    case '*':  
        index = 2;  
        break;  
    case '/':  
        index = 3;  
        break;  
    case '(':  
        index = 4;  
        break;  
    case ')':  
        index = 5;  
        break;  
    case '#':  
        index = 6; 
    default:break;  
    }  
    return index;  
}  
  
char getPriority(char theta1, char theta2)
{  
    const char priority[][7] = 
    {  
        { '>','>','<','<','<','>','>' },  
        { '>','>','<','<','<','>','>' },  
        { '>','>','>','>','<','>','>' },  
        { '>','>','>','>','<','>','>' },  
        { '<','<','<','<','<','=','0' },  
        { '>','>','>','>','0','>','>' },  
        { '<','<','<','<','<','0','=' },  
    };  
    int num1 = getIndex(theta1);  
    int num2 = getIndex(theta2);  
    return priority[num1][num2]; 
}
int calculate(int b, char ff, int a) 
{  
    switch (ff)  
    {  
    case '+':  
        return b + a;  
    case '-':  
        return b - a;  
    case '*':  
        return b * a;  
    case '/':  
        return b / a;  
    default:  
        break;  
    }  
} 
int main()
{
    string temp;
    cin >> temp;
    temp+="###";
    int numok = 0;
    int of = 0;
    f1.push('#');
    for(int i = 0 ;i < temp.size() ;i++)
    {
        if(isdigit(temp[i]))
        {
            if(numok == 1)
            {
                int t = f2.top();
                f2.pop();
                f2.push(10*t + temp[i] -'0');
                numok = 1;
            }
            else
            {
                f2.push(temp[i] - '0');
                numok++;
            }
            if(f2.size() == 1&&of == 1)
            {
                int t = f2.top();
                f2.pop();
                f2.push(-t);
                of = 0;
            }
        }
        else
        {
            numok = 0;
            switch (getPriority(f1.top(), temp[i]))
            {  
            case '<':               //<则入栈f1 
                if(f2.empty()&&temp[i] == '-')
                {of = 1;break;}
                f1.push(temp[i]);   
                break;  
            case '=':               //=括号的处理  
                f1.pop();  
                break;  
            case '>':               //>则计算  
                char theta = f1.top();  
                f1.pop(); 
                int a = f2.top();  
                f2.pop();  
                int b = f2.top();  
                f2.pop();  
                f2.push(calculate(b, theta, a));  
                if(temp[i] != ')')
                f1.push(temp[i]);
                if(temp[i] == ')' && f1.top() == '(')
                f1.pop();
            }  
        }
    }
    cout << f2.top();
}