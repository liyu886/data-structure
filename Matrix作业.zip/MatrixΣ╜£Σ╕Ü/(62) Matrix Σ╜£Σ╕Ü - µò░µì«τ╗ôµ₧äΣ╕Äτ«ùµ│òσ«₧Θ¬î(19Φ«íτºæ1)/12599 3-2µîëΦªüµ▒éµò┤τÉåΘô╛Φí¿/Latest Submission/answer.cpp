#include<bits/stdc++.h>
using namespace std;
struct linkNode {
     int val;
     linkNode *next;
         linkNode(){
            val=0;
            next=NULL;
        }
     linkNode(int x) : val(x), next(NULL) {}
 };
linkNode* partList(linkNode* head, int x)
{
    linkNode * curr = head;
    int a[1000],b[1000];
    int t1 = 0,t2= 0;
    while(curr!= NULL)
    {
        if(curr->val<x)
        {
            a[t1++] = curr->val;
        }
        else
        b[t2++] = curr->val;
        curr = curr->next;
    }
    curr = head;
    for(int i =0; i<t1;i++)
    {
        curr->val = a[i];
        curr = curr->next;
    }
    for(int i =0; i<t2;i++)
    {
        curr->val = b[i];
        curr = curr->next;
    }
    return head;
}