#include <stdio.h>
#include "linkNode.h"
linkNode *partList(linkNode *head, int x) {
        linkNode *leftHead = new linkNode();
        linkNode *rightHead = new linkNode();
        linkNode *lpre = leftHead,*rpre = rightHead;
        while(head != NULL){
            if(head->val < x){
                lpre->next = head;
                lpre = head;
            }
            else{
                rpre->next = head;
                rpre = head;
            }
            head = head->next;
        }
        rpre->next = NULL;
        lpre->next = rightHead->next;
        return leftHead->next;
    }