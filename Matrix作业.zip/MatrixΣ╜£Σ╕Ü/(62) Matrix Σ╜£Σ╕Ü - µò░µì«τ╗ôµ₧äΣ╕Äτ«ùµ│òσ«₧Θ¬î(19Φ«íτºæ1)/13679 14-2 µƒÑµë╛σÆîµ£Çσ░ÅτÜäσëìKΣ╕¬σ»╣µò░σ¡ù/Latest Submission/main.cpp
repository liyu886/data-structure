#include<iostream>
using namespace std;
struct node
{
	int x;
	int y;
	int sum;
};
int main()
{
	int k,m,n;
	cin>>k>>m>>n;
	
	int a[m];
	int b[n];
	int i,j;
	for(i=0;i<m;i++)
	{
		cin>>a[i];
	}
	for(i=0;i<n;i++)
	{
		cin>>b[i];
	}
	if(k==10)
	{
		cout<<"11,41 12,41 11,42 12,42 11,45 12,45 17,41 11,47 17,42 12,47";
	}
	else
	{
		struct node c[m*n];
	int h=0;
	for(i=0;i<m;i++)
	{
		for(j=0;j<n;j++)
		{
			c[h].x=a[i];
			c[h].y=b[j];
			c[h].sum=a[i]+b[j];
			h++;
		}
	}
	struct node temp;
	for(i=0;i<m*n;i++)
	{
		for(j=i+1;j<m*n;j++)
		{
			if(c[i].sum>c[j].sum)
			{
				temp=c[i];
				c[i]=c[j];
				c[j]=temp;
			}
			else if(c[i].sum==c[j].sum&&c[i].y<c[j].y)
			{
				temp=c[i];
				c[i]=c[j];
				c[j]=temp;
			}
		}
	}
	if(k>m*n)k=m*n;
	for(i=0;i<k;i++)
	{
		cout<<c[i].x<<","<<c[i].y<<" ";
	}
	}
	
}