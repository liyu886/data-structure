
#include<bits/stdc++.h>
#include <cstddef>
using namespace std;
 struct linkNode {
     int val;
     linkNode *next;
     linkNode(int x) : val(x), next(NULL) {}
 };
linkNode *getIntersectionNode(linkNode *headA, linkNode *headB)
{
    int a[10000],b[10000];
    int t1=0,t2=0;
    linkNode *curr1 = headA;
    linkNode *curr2 = headB;
    while(curr1->next!=NULL)
    {
        a[t1++] = curr1->val;
        curr1=curr1->next;
    }
    while(curr2->next!=NULL)
    {
        b[t2++] = curr2->val;
        curr2=curr2->next;
    }
    int key = 0,ok=1;
    for(int i =0;i<t1;i++)
    {
        for(int j =0;j<t2;j++)
        {
            ok = 1;
            if(a[i]==b[j])
            {
                for(int i1=i,j1=j;i1<t1;i1++,j1++)
                {
                    if(a[i1]!=b[j1])
                    {
                        ok = 0;
                        break;
                    }
                }
                if(ok == 1)
                {
                    key = a[i];
                    goto x;
                }
            }
        }
    }
    x:
    curr1 = headA;
    while(curr1->next!=NULL)
    {
        if(key == curr1->val)
        return curr1;
        curr1=curr1->next;
    }
}