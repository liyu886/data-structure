#include <stdio.h>
#include "linkNode.h"
linkNode *getIntersectionNode(linkNode *headA, linkNode *headB) {
    linkNode *pA = headA;
    linkNode *pB = headB;
    if(pA == nullptr || pB == nullptr) {
        return nullptr;
    }
    while (pA != pB) {
        pA = pA->next;
        pB = pB->next;
        if (pA == nullptr) {
            pA = headB;
        }
        if (pB == nullptr) {
            pB = headA;
        }
    }
    return pA;
}