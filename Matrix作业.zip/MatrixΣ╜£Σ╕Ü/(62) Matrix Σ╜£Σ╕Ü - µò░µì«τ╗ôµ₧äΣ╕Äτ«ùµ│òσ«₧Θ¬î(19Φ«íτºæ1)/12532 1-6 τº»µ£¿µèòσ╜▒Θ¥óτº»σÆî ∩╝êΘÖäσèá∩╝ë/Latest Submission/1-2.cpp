#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a[3][3];
    int x=0,y=0,z=0;
    for(int i =0;i<3;i++)
    for(int j =0;j<3;j++)
    {   
        cin>>a[i][j];
        if(a[i][j]!=0)
        x++;
    }
    int temp = 0;
    for(int i =0;i<3;i++)
    {
        for(int j =0;j<3;j++)
        {   
            if(a[i][j]>temp)
            temp = a[i][j];
        }
        y+=temp;
        temp =0;
    }
    temp = 0;
    for(int i =0;i<3;i++)
    {
        for(int j =0;j<3;j++)
        {   
            if(a[j][i]>temp)
            temp = a[j][i];
        }
        z+=temp;
        temp =0;
    }
    cout<<x+y+z;
}