#include <iostream>
#include <string>
#include <vector>
#include <time.h>
#include <algorithm>
using namespace std;
int binary_search(vector<int> &num, int target);
