#include "function.h"
int binary_search(vector<int> &num, int target)
{
	int low=0;
    int high=num.size();
	int mid;
	while(low<high)
	{
		mid=(low+high)/2;
		if(num[mid] == target)
		{
			return mid;
		}
		else if(target>num[mid])
		{
			low = mid+1;
			
		}
		else high = mid-1;
	}
	return -1;
}
