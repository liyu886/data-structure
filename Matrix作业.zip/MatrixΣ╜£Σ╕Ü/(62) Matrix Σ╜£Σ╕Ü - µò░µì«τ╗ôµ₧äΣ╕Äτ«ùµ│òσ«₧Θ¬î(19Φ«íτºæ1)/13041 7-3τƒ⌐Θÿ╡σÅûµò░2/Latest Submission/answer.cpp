#include<bits/stdc++.h>
using namespace std;
int dp[15][15][15][15];
int ma[15][15];
int main()
{
    int n;
    cin >> n;
    int a,b,c;
    while(1)
    {
        cin >> a>>b>>c;
        if(a==0&&b==0&&c==0)
        {
            break;
        }
        ma[a][b] = c;
    }
    for(int i = 1; i<=n;i++)
    for(int j = 1; j<=n;j++)
    for(int k = 1; k<=n;k++)
    for(int m = 1; m<=n;m++)
    {
        dp[i][j][k][m] = max(dp[i-1][j][k-1][m],max(dp[i-1][j][k][m-1],max(dp[i][j-1][k-1][m],dp[i][j-1][k][m-1])))+ma[i][j]+ma[k][m];
        if(i==k&&j==m) dp[i][j][k][m]-=ma[k][m];
    }
    cout << dp[n][n][n][n];
}