#include"List.h"
Node* List::SearchkthNode(int k)
{
    if(k==0) return NULL;
    if(head == NULL) return NULL;
    Node * curr = head;
    for(int i = 0; i< k-1;i++)
    {
        curr = curr->next;
        if(curr == NULL) return NULL;
    }
    return curr;
}
void List::InsertBack(Node* n)
{
    if(head == NULL)
    head = new Node(n->value);
    else
    {
        Node *curr = head;
        while(curr->next!=NULL)
        curr = curr->next;
        curr->next = new Node(n->value);
    }
}
void List::DeleteElement(int k)
{
    if(head == NULL) return;
    if(k == 1)
    {
        Node *temp = head;
        head = head->next;
        delete temp;
        return;
    }
    Node * curr = head;
    for(int i = 0; i< k-2;i++)
    {
        curr = curr->next;
    }
    Node *temp = curr->next;
    curr->next = temp->next;
    delete temp;
}
void List::InsertAfterKth(Node* n, int k)
{
    if(k==0)
    {
        Node *temp = new Node(n->value);
        temp->next = head;
        head = temp;
        return;
    }
    Node * curr = head;
    for(int i = 0; i< k-1;i++)
    {
        curr = curr->next;
    }
    Node *temp = new Node(n->value);
    temp->next = curr->next;
    curr->next = temp;
}