#include<bits/stdc++.h>
using namespace std;
int d[1000];
int vis[1000];
int main()
{
    int n;
    cin >> n;
    int cost[n+1][n+1];
    memset(cost,0,sizeof(cost));
    for(int i = 1; i <= n;i++)
    {
        for(int j = i+1; j <= n; j++)
        cin >> cost[i][j];
    }
    for(int i = 1; i <= n;i++)
    d[i] = cost[1][i];
    int u,v;
    while(1)
    {
        v = -1;
        for(u = 1; u <= n ;u++)
        {
            if(!vis[u] &&(v == -1||d[u] < d[v]))
            v = u;
        }
        if(v == -1) break;
        vis[v] = 1;
        for(u = 1; u <= n ;u++)
        {
            d[u] = min(d[u],cost[v][u] != 0? d[v]+cost[v][u]:d[u] );
        }
    }
    cout << d[n];
}