#include "circle.h"
#include<iostream>
#include<stack>

using namespace std;

void Graphcircle(GraphList *g){
	int count[g->numVertex],del[g->numVertex];
		for(int i=0;i<g->numVertex;i++){
			del[i]=0;
            count[i]=0;
		}
	for(int i=0;i<g->numVertex;i++){
		EdgeNode *p=g->adjList[i].firstedge;
		while(p){
			count[p->adjvex]++;
			p=p->next;
		}
	}
	stack<int> s;
	int num=0;
	for(int i=0;i<g->numVertex;i++){
		if(count[i]==0){
			s.push(i);
		}
	}
	while(!s.empty()){
		int w=s.top();
		s.pop();
		num++;
		del[w]=1;
		EdgeNode *p=g->adjList[w].firstedge;
		while(p)
        {
			count[p->adjvex]--;
            if(count[p->adjvex]==0){s.push(p->adjvex);
              
            }
			p=p->next;
		}
	}
	 
	 if(num==g->numVertex) cout<<"no circle"<<endl;
	 else cout<<"has circle"<<endl;
}