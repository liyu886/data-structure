#include "graphlist.h"
void Graphcircle(GraphList *g);