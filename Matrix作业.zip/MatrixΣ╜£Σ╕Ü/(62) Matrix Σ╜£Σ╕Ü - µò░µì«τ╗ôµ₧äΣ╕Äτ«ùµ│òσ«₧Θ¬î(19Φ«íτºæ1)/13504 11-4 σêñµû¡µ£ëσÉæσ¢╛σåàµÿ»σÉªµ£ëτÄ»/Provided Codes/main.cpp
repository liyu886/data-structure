#include "circle.h"
int main() {
	GraphList g;
	createGraph(&g);
	Graphcircle(&g);
	return 0;
}