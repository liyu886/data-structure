#include<bits/stdc++.h>
using namespace std;
struct node
{
    int val;
    int left;
    int right;
}tree[100];
int siz[100];
int ans = 0; 
int dfs(int N)
{
    if(tree[N].left!=-1) siz[N] += dfs(tree[N].left);
    if(tree[N].right!=-1) siz[N] += dfs(tree[N].right);
    return siz[N];
}
bool check(int a,int b)
{
    if(a == -1&&b == -1) return true;
    if(a != -1&&b != -1&&check(tree[a].left,tree[b].right)&&check(tree[a].right,tree[b].left)&&tree[a].val==tree[b].val) return true;
    return false;
}
int main()
{
    int n;
    cin >> n;
    for(int i = 1;i <= n;i++)
    {
        cin >> tree[i].val;
        siz[i] = 1;
    }
    for(int i = 1;i <= n;i++)
    cin >> tree[i].left >> tree[i].right;
    dfs(1);
    for(int i = 1;i <= n;i++)
    if(check(tree[i].left,tree[i].right))
    ans = max(ans,siz[i]);
    cout << ans;
}