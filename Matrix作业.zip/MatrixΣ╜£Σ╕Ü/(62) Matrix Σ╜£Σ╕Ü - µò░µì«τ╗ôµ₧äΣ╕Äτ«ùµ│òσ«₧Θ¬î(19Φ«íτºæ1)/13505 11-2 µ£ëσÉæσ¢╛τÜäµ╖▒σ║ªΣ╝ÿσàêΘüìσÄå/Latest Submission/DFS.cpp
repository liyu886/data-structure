#include"dfs.h"
#include<bits/stdc++.h>
using namespace std;
void DFS(int i,GraphList *g,int * dis)
{
    cout << g->adjList[i].value << " ";
    dis[i] = 1;
    EdgeNode * temp = g->adjList[i].firstedge;
    while(temp != NULL)
    {
        if(!dis[temp->adjvex])
        DFS(temp->adjvex,g,dis);
        temp = temp->next;
    }
}
void DFSTraverse(GraphList *g)
{
    int * dis = new int [g->numVertex];
    memset(dis,0,sizeof(4 * g->numVertex));
    for(int i = 0; i < g->numVertex;i++)
    {
        if(dis[i] == 0)
        DFS(i,g,dis);
    }
}
