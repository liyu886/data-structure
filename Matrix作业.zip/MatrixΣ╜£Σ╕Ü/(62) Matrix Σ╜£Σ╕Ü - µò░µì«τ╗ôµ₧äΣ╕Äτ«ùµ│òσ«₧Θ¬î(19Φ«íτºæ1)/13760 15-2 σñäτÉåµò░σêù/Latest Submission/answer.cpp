#include<bits/stdc++.h>
using namespace std;
map<int,int>m;
int main()
{
    int n;
    cin >> n;
    int a[1000];
    int count = 0;
    for(int i = 0; i < n;i++)
    {
        int temp;
        cin >> temp;
        if(m.find(temp) == m.end())
        {
            m[temp] = 1;
            a[count++] = temp;
        }
    }
    cout << count << endl;
    sort(a,a+count);
    for(int i = 0 ;i < count ; i++)
    cout << a[i] << " ";
}