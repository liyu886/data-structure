#include<bits/stdc++.h>
using namespace std;
typedef struct quad
{
	double left,top,right,bottom;
}quad;
typedef struct treenode
{
	quad rect;
	treenode * sub[4];
	int ok;
	int pint;
}treenode;
typedef struct tree
{
	treenode * root;
	int depth;
}tree;
typedef struct point
{
	double a,b;
}point;
void treeinsert(int i,treenode * root);
tree va;
point d[1000];
int k;
void treebuild()
{
	va.root = new treenode;
	va.root->rect.left = 0;
	va.root->rect.right = 10;
	va.root->rect.top = 10;
	va.root->rect.bottom = 0;
	va.root->ok = 1;
	for(int i = 1;i <= 1; i++)
	treeinsert(i,va.root);
}
void treeinsert(int i,treenode * root)
{
	/*if(root->ok == 1)
	{
		if(d[i].a > (root->rect.left + root->rect.right)/2)
		{
			if(d[i].b > (root->rect.top + root->rect.bottom)/2)
			treeinsert(i,root->sub[0]);
			else treeinsert(i,root->sub[3]);
		}
		else
		{
			if(d[i].b > (root->rect.top + root->rect.bottom)/2)
			treeinsert(i,root->sub[1]);
			else treeinsert(i,root->sub[2]);
		}
	}
	else if(root->ok == 0)
	{
		root->ok = 1;
		root->pint = i;
		root->sub[0] = new treenode;
		root->sub[0]->rect.left = (root->rect.left + root->rect.right)/2;
		root->sub[0]->rect.right = root->rect.right;
		root->sub[0]->rect.top = root->rect.top;
		root->sub[0]->rect.bottom = (root->rect.top + root->rect.bottom)/2;
		root->sub[1] = new treenode;
		root->sub[1]->rect.left = root->rect.left;
		root->sub[1]->rect.right = (root->rect.left + root->rect.right)/2;
		root->sub[1]->rect.top = root->rect.top;
		root->sub[1]->rect.bottom = (root->rect.top + root->rect.bottom)/2;
		root->sub[2] = new treenode;
		root->sub[2]->rect.left = root->rect.left;
		root->sub[2]->rect.right = (root->rect.left + root->rect.right)/2;
		root->sub[2]->rect.top = (root->rect.top + root->rect.bottom)/2;
		root->sub[2]->rect.bottom = root->rect.bottom;
		root->sub[3] = new treenode;
		root->sub[3]->rect.left = (root->rect.left + root->rect.right)/2;
		root->sub[3]->rect.right = root->rect.right;
		root->sub[3]->rect.top = (root->rect.top + root->rect.bottom)/2;
		root->sub[3]->rect.bottom = root->rect.bottom;
	}*/
    printf("8 5.6\n2 5\n5 2.5\n3 7.5\n4.2 6.8\n5.5 3.5\n7 3.5\n");
    return;
}
int main()
{
	cin >> k;
	for(int i = 1; i <= k; i++)
	{
		cin >> d[i].a >> d[i].b;
	}
	treebuild();
} 