#include <list>
#include <vector>
#include <queue>
#include <iostream>
using namespace std;
class quadrect {
public:
	double  left,
		top,
		right,
		bottom;
};
class point {
public:
	double x, y;
};
class node {
public:
	quadrect rect;
	list<point> points;
	node* sub[4];
	bool haschild() {
		bool flag = true;
		if (sub[0] == nullptr &&
			sub[1] == nullptr &&
			sub[2] == nullptr &&
			sub[3] == nullptr) {
			flag = false;
		}
		return flag;
	}
	bool storeobj() {
		return points.size() != 0;
	}
	node() {
	}
	node(quadrect inrect) :rect(inrect) {
	}
};

void clearnullroot(node* t) {
	node* parent = t;
	// 是否有子节点
	if (parent->haschild()) {
		// 有子节点
		for (int i = 0; i < 4; i++) {
			// 该子节点非空的情况下
			if (parent->sub[i] != nullptr) {
				// 该子节点是否有子节点
				if (parent->sub[i]->haschild()) {
					clearnullroot(parent->sub[i]);
				}
				// 没有子节点是否有内容
				else if (parent->sub[i]->storeobj()) {

				}
				// 既没有子节点又没有内容
				else if (!parent->sub[i]->storeobj()) {
					delete parent->sub[i];
					parent->sub[i] = nullptr;
				}
				
			}
		}
	}
}

int getindex(point p, quadrect rect) {
	// 浮点数 分界线比较 可能出现问题
	int index = 3;
	double eps = 0.00000001;
	if (p.y - (rect.top + rect.bottom) / 2 > eps) {
		index = index / 2; // 在上面
	}
	if (p.x - (rect.left + rect.right) / 2 < eps) {
		index = index - 1; // 在左边
	}
	return index;
}

void quadinsert(point p, node* n) {
	if (n->haschild()) {
		// 根据节点的rect和point的坐标判断在哪个子节点
		int index = getindex(p, n->rect);
		quadinsert(p, n->sub[index]);
	}
	else if (n->storeobj()) {
		// 划分四个子区域
		quadrect UL, UR, LL, LR;
		double left = n->rect.left;
		double right = n->rect.right;
		double top = n->rect.top;
		double bottom = n->rect.bottom;
		double midx = (left + right) / 2;
		double midy = (top + bottom) / 2;
		UL.left = LL.left = left;
		UL.right = LL.right = UR.left = LR.left = midx;
		UR.right = LR.right = right;
		UL.top = UR.top = top;
		UL.bottom = UR.bottom = LL.top = LR.top = midy;
		LL.bottom = LR.bottom = bottom;
		// 创建四个子孩子
		n->sub[0] = new node(UL);
		n->sub[1] = new node(UR);
		n->sub[2] = new node(LL);
		n->sub[3] = new node(LR);
		int prevpoint_index = getindex(n->points.front(), n->rect);
		n->sub[prevpoint_index]->points.push_back(n->points.front());
		n->points.pop_front();
		int index = getindex(p, n->rect);
		quadinsert(p, n->sub[index]);

	}
	else if (!(n->storeobj())) {
		n->points.push_back(p);
	}
}
node* quadtreebuild(int n) {
	node* root = new node();
	quadrect rect;
	// 设置四叉树范围
	rect.left = 0;
	rect.right = 10;
	rect.bottom = 0;
	rect.top = 10;
	root->rect = rect;
	vector<point> points;
	for (int i = 0; i < n; i++) {
		point t;
		double x, y;
		cin >> x;
		cin >> y;
		t.x = x; t.y = y;
		points.push_back(t);
	}
	// 设置点数据
	for (int i = 0; i < points.size(); i++) {
		quadinsert(points[i], root);
	}
	// 清空多余的节点
	clearnullroot(root);
	return root;
}
bool pointequal(point& a, point& b) {
	return (a.x == b.x && a.y == b.y);
}
void printquadTree(node* root) {
	node* t = root;
	queue<node*> q;
	if (t != nullptr) {
		q.push(t);
	}
	while (!q.empty()) {
		t = q.front();
		q.pop();
		if (!t->points.empty()) {
			cout << t->points.front().x << " " << t->points.front().y << endl;
		}
		for (int i = 0; i < 4; i++) {
			if (t->sub[i] != nullptr) {
				q.push(t->sub[i]);
			}
		}
	}
}
int main() {
	int n;
	cin >> n;
	node * root;
	root = quadtreebuild(n);
	printquadTree(root);
	return 0;
}