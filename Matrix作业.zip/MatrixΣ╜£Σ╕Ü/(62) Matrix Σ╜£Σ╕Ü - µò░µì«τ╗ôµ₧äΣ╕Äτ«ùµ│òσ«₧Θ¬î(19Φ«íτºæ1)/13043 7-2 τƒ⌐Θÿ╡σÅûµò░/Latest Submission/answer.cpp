#include<bits/stdc++.h>
using namespace std;
int n,m,ans;
int ma[15][15];
int vis[15][15];
int dx[]={0,1,1,1,0,0,-1,-1,-1};
int dy[]={0,0,1,-1,1,-1,0,1,-1};
void dfs(int r,int c,int sum)
{
    if(c>m)
    {
        r++;
        c=1;
    }
    if(r>n)
    {
        ans = max(ans,sum);
        return;
    }
    if(!vis[r][c])
    {   
        for(int i =0;i<9;i++)
        vis[r+dx[i]][c+dy[i]]++;
        dfs(r,c+2,sum+ma[r][c]);
        for(int i =0;i<9;i++)
        vis[r+dx[i]][c+dy[i]]--;
    }
    dfs(r,c+1,sum);
}
int main()
{
    cin >> n>>m; 
    for(int i = 1;i <= n;i++)
    for(int j = 1;j <= m;j++)
    {
        cin >> ma[i][j];
    }
    dfs(1,1,0);
    cout<<ans<<endl;
}