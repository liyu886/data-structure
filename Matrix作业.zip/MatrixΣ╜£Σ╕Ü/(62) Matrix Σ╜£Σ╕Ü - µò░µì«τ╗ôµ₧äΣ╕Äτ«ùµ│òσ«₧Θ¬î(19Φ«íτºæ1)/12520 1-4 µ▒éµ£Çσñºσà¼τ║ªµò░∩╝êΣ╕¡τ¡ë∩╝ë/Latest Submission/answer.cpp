#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a,b;
    cin >> a >> b;
    if(a > b)
    swap(a,b);
    int r = a % b;
    while(r>0)
    {
        a = b;
        b = r;
        r = a % b;
    }
    cout << b;
    
}