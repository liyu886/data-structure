#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<queue>
using namespace std;
struct node{
    int id,st,re,pr;
    bool operator < (const node &a)const{
        if(pr==a.pr)  return st>a.st;
        else return pr<a.pr;
    }
};
node c;
long long ti;
priority_queue<node>q;
int main(){
    while(scanf("%d%d%d%d",&c.id,&c.st,&c.re,&c.pr)!=EOF){
        while(!q.empty()&&ti+q.top().re<=c.st){
            node b=q.top();
            q.pop();
            printf("%d %lld\n",b.id,ti+b.re);
            ti+=b.re;
        }
        if(!q.empty()){
            node d=q.top();
            q.pop();
            d.re=d.re-c.st+ti;
            q.push(d);
        }
        q.push(c);
        ti=c.st;
    }
    while(!q.empty()){
        node f=q.top();
        q.pop();
        ti+=f.re;
        printf("%d %lld\n",f.id,ti);
    }
    return 0;
}