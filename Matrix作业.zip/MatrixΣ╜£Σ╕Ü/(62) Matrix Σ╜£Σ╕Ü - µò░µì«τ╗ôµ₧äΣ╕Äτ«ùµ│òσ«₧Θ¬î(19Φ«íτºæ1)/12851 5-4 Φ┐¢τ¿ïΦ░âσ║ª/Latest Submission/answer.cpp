#include<bits/stdc++.h>
using namespace std;
struct node
{
    int id;
    int adtime;
    int needtime;
    int p;
    node()
    {

    }
    node(int a,int b,int c,int d)
    {
        id = a;
        adtime = b;
        needtime = c;
        p = d;
    }
    bool operator <(const node & other)const
    {
        return p < other.p|| p ==other.p&&adtime >other.adtime;
    }
}s[10000];
int main()
{
    int id,adtime,needtime,p;
    priority_queue<node> q;
    int nowtime = 0;
    int cnt = 0;
    while(cin >> id>>adtime>>needtime>>p)
    {
        s[++cnt] = node(id,adtime,needtime,p);
    }
    int num = cnt;
    int curr = 1;
    s[++cnt].adtime = 100000000;
    while(num != 0)
    {
        if(q.empty())
        {
            q.push(s[curr]);
            nowtime = s[curr].adtime;
            curr++;
        }
        node temp = q.top();
        q.pop();
        int lasttime = nowtime;
        nowtime = min(s[curr].adtime,temp.needtime+lasttime);
        if(nowtime == lasttime + temp.needtime)
        {
            cout << temp.id << " "<< nowtime << endl;
            num--;
        }
        else
        {
            temp.needtime -= nowtime - lasttime;
            q.push(temp);
        }
        if(nowtime == s[curr].adtime)
        {
            q.push(s[curr]);
            curr++;
        }
    }
}