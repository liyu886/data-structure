#include<iostream>
#include<cstdio>
#include<stdio.h>
#include<algorithm>
#include<cmath>/*2分，搜索*/
using namespace std;
int n,m;
int tot=0;//用tot这个数组来记录这个数组的蛋糕总数 
int size_cake[55],num_peo[2000];
int sum[2025];//sum这个数组用来记前缀和 
int l,r;bool flag; 
int chi;
int ck;
//剪枝过程更多的是在dfs的判断中， 
void dfs(int x,int y)
{
    if(x<1)
    //分蛋糕的过程就像是乌鸦用石子，沙子，水去填满一个瓶子，聪明的乌鸦一定是先去用大的体积的东西去填，然后是小的
    //一旦是确定（假定） 了可以喂饱的人，就是要求到这往前从后往前喂同学们，如果分到了一个人，这个人的序号比1还要小，那么就是说明喂完了所有人
//返回true就ok  
    {
        flag=true;
        return;
    }
    for(int i=y;i<=n;i++)//是从第y块蛋糕开始分 
    {
        if(tot<chi)return;//如果我的 蛋糕的总数比人的需求总量还要少，那么不管我怎么去分蛋糕，我的结果都是false，这时候就没必要了直接返回
        if(flag)return;
        if(x<1)
        {
            flag=true;
            return;
         } 
         if(size_cake[i]>=num_peo[x])
         {
            size_cake[i]-=num_peo[x];
            tot-=num_peo[x];
            chi-=num_peo[x];
            if(tot<num_peo[1]&&x!=1)return;
            if(size_cake[i]<num_peo[1])tot-=size_cake[i];
            if(num_peo[x]==num_peo[x-1])dfs(x-1,i);
            else dfs(x-1,1);    
            if(size_cake[i]<num_peo[1])tot+=size_cake[i];
            size_cake[i]+=num_peo[x];
            tot+=num_peo[x];
            chi+=num_peo[x]; 
         }//因为这个过程不过只是自己假象的，所以就像是把皇后一样，一定要回溯，最后的时候蛋糕一点都会少，人们吃的蛋糕都会吐出来的 
    }
}
int main()
{
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        scanf("%d",&size_cake[i]);
        tot+=size_cake[i];
    } 
    scanf("%d",&m);
    for(int j=1;j<=m;j++)scanf("%d",&num_peo[j]);
    sort(num_peo+1,num_peo+1+m);
    for(int i=1;i<=m;i++) sum[i]=sum[i-1]+num_peo[i];//前缀和是上一个人的前缀和+本人的嘴的大小 
    //先要进行第一个优化，如果给出一个前缀和，在二分答案之前首先要筛掉一些没有用的，就是如果前缀和大于tot，前缀和就要向前移动
    int oo=m;
    while(sum[oo]>tot)oo--;//通过前缀和饿进行优化 可以通过这一些剪枝来 减去没有必要的二分区间
    l=1,r=oo;
    while(l<=r)
    {
        int mid=(l+r)/2;
            flag=false;
        chi=sum[mid];
        dfs(mid,1);//mid是当前开始的人们所需要的蛋糕数目的总和，1是指从第一块蛋糕开始搜索
        //其实，蛋糕排序与否并不重要，都无所谓，不怕浪费时间去sort一行就自己写呗
        //dfs就是依据情况而定的check函数，不管怎么样，check函数都会返回一个值，根据这个值的情况进行下一步操作
        if(flag)//情况时可行的
        {
            l=mid+1;    
         } 
         else{
            r=mid-1;
         }

    }
    cout<<l-1<<endl;
}