#include<bits/stdc++.h>
using namespace std;
int n,m;
int a[55],b[55],peo[1050];
bool check(int N)
{
    int roll = 1000;
    while(roll--)
    {
        for(int i = 1;i <= n ;i++)
        {
            b[i] = a[i];
        }
        random_shuffle(b+1, b+n+1);
        int ok;
        for(int j = N;j>=1;j--)
        {
            ok = 0;
            for(int i = 1;i <= n;i++)
            {
                if(b[i] >= peo[j])
                {
                    b[i] -= peo[j];
                    ok = 1;
                    break;
                }
            }
            if(!ok) break;
        }
        if(ok) return true; 
    }
    return false;
}
int main()
{   
    cin >> n;
    for(int i = 1; i <= n ;i++)
    {
        cin >> a[i];
    }
    cin >> m;
    for(int i = 1;i <= m ;i++)
    {
        cin >> peo[i];
    }
    sort(peo+1,peo+m+1);
    int l = 0,r = m;
    int ans= 0;
    int mid;
    for(int i = m; i>=1;i--) 
	{
		if(check(i))
		{
			ans = i;
			break;
		}
	}
    printf("%d",ans);
}