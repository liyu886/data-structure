#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a[5];
    for(int i =0 ;i<5;i++)
    {
        cin >> a[i];
    }
    int key;
    cin >> key;
    int ok = 0;
    for(int i =0 ;i<5;i++)
    {
        if(a[i] == key)
        {
            printf("%d\n",i);
            ok = 1;
        }
    }
    if(ok == 0)
    printf("-1");
}