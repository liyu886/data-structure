#include<bits/stdc++.h>
using namespace std;
char a[1000];
char b[1000];
int main()
{
    cin >> a >> b;
    int ans = 0;
    for(int i = 0; i < strlen(a);i++)
    for(int j = 1; j < strlen(b);j++)
    {
        if(a[i]==b[j]&&a[i+1]==b[j-1])
        ans++;
    }
    cout << 2 * ans;
}