#include <iostream>
#include <cstring>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
using namespace std;

bool isLeft(char a)
{
	return (a == '(') || (a == '[') || (a == '{');
}

bool isRight(char a)
{
	return (a == ')') || (a == ']') || (a == '}');
}

bool isMatch(char a, char b)
{
	if (a == '('&&b == ')')
	{
		return true;
	}
	else if (a == '['&&b == ']')
	{
		return true;
	}
	else if (a == '{'&&b == '}')
	{
		return true;
	}
	return false;
}

int main()
{
	string str;
	vector<char> cvec;
	cvec.reserve(200);
	cin >> str;

	auto iter = str.begin();
	for (; iter != str.end(); ++iter)
	{
		//左括号直接进栈
		if (isLeft(*iter))
		{
			cvec.push_back(*iter);
		}
		//如果出现右括号
		else if (isRight(*iter))
		{
			//不合理情况1： 栈空的话，直接退出    这里情况一开始忘记考虑，但是华为机试仍然100%通过
			if (cvec.empty())
			{
				break;
			}
			char c = cvec.back();
			cvec.pop_back();
			//不合理情况2：判断栈中左括号与现在的右括号是否匹配
			if (!isMatch(c, *iter))
			{
				break;
			}
		}
	}
	//处理不合理情况1，2  以及不合理情况3：字符已经遍历结束，但是栈仍然非空
	if (iter != str.end() || !cvec.empty())
	{
		cout << "False" << endl;
	}
	else
	{
		cout << "True" << endl;
	}
	return 0;
}