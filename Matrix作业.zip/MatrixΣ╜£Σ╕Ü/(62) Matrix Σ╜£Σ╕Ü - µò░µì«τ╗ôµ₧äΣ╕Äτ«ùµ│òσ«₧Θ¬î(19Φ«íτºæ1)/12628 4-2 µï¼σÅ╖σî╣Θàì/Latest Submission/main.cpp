#include<bits/stdc++.h>
using namespace std;
int main()
{
    stack<char> a;
    string temp;
    cin >> temp;
    for(int i = 0; i < temp.size() ;i++)
    {
        if(temp[i] == '('|| temp[i] == '{'||temp[i] == '[')
        a.push(temp[i]);
        if(temp[i] == ')')
        {
            if(a.top() == '(')
            {
                a.pop();
            }
            else a.push(temp[i]);
        }
        if(temp[i] == '}')
        {
            if(a.top() == '{')
            {
                a.pop();
            }
            else a.push(temp[i]);
        }
        if(temp[i] == ']')
        {
            if(a.top() == '[')
            {
                a.pop();
            }
            else a.push(temp[i]);
        }
    }
    if(a.empty()) cout <<"True"<<endl;
    else cout <<"False"<<endl;
}