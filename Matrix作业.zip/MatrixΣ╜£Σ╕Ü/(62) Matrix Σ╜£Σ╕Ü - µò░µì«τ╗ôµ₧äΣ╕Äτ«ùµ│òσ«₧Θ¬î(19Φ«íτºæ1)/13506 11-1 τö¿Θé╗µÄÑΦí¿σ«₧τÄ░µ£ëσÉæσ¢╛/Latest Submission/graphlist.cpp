#include"graphlist.h"
using namespace std;
void createGraph(GraphList* g)
{
    int k,m;
    cin >> k >> m;
    for(int i = 0 ;i < k ;i++)
    cin >> g->adjList[i].value;
    for(int i = 0; i < m; i ++)
    {
        int a,b,c;
        cin >> a >> b >> c;
        if(g->adjList[a].firstedge == NULL)
        {
            g->adjList[a].firstedge = new EdgeNode;
            g->adjList[a].firstedge->adjvex = b;
            g->adjList[a].firstedge->weight = c;
            g->adjList[a].firstedge->next = NULL;
        }
        else
        {
            EdgeNode * temp = g->adjList[a].firstedge;
            while(temp->next != NULL)
            temp = temp->next;
            temp->next = new EdgeNode;
            temp->next->adjvex = b;
            temp->next->weight = c;
            temp->next->next = NULL;
        }
    }
}