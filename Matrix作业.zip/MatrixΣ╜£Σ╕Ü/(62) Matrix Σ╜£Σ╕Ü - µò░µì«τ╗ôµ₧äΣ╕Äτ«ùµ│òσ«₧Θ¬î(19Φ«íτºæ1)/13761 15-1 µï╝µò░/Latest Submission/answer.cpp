#include<bits/stdc++.h>
using namespace std;
int n;
string a[1000];
string ans;
int main()
{
    cin >> n;
    for(int i = 0; i < n ;i++)
    cin >> a[i];
    sort(a,a+n,greater<string>());
    for(int i = 0; i < n ;i++)
    ans += a[i];
    cout << ans;
}