#include "bfs.h"
#include<bits/stdc++.h>
using namespace std;
queue<int> a;
void BFS(int v,GraphList *g,int * dis);
void BFSTraverse(GraphList *g)
{
    int * dis = new int [g->numVertex];
    memset(dis,0,sizeof(4 * g->numVertex));
    for(int i = 0 ;i < g->numVertex;i++)
    {
        if(!dis[i])
        BFS(i,g,dis);
    }
}
void BFS(int v,GraphList *g,int * dis)
{
    dis[v] = 1;
    a.push(v);
    cout << v << " ";
    while(!a.empty())
    {
        int num = a.front();
        EdgeNode * temp = g->adjList[num].firstedge;
        while(temp != NULL)
        {
            if(dis[temp->adjvex] == 0)
            {
                cout << temp->adjvex << " ";
                dis[temp->adjvex] = 1;
                a.push(temp->adjvex);
            }
            temp = temp->next;
        }
        a.pop();
    }
}