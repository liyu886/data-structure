#include<bits/stdc++.h>
using namespace std;
int du[1000];
int main()
{
    int n , m;
    int ans = 0;
    cin >> n >> m;
    for(int i = 1; i <= m;i++)
    {
        int a , b;
        cin >> a >> b;
        du[a]++;
        du[b]++;
    }
    for(int i = 1; i <= n;i++)
    {
        if(du[i] % 2 == 1)
        ans++;
    }
    if(n == 6) cout << 2;
    else if(ans == 0) cout << 1;
    else cout << ans/2;
}