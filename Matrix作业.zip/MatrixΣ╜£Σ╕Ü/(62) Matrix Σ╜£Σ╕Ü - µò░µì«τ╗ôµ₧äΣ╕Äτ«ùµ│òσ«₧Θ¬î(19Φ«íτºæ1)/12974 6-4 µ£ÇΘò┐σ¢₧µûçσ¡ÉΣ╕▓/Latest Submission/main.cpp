#include<bits/stdc++.h>
using namespace std;
int main()
{
    string s;
    cin >> s;
    int n = s.length();
    string ans;
    for(int i = 0;i < n-1;i++)
    for(int j = n-1;j>i;j--)
    {
        if(i == 9)
        int sb = i;
        if(s[i] == s[j])
        {
            int i1 = i;
            int j1 = j;
            while(s[i1] == s[j1])
            {
                if(j-i+1 > ans.length()&&(j1-i1==1||j1==i1))
                ans = s.substr(i,j-i+1);
                i1++;
                j1--;
            }
        }
    }
    cout << ans;
}