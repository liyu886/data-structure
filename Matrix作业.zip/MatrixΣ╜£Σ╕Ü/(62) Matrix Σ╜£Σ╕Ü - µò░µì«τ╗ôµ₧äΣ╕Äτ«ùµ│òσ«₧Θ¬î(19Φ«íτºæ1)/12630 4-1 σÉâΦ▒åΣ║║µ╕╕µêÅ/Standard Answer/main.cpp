#include<stdio.h>
int a[100010];
int main() {
	int n;	
	scanf("%d", &n);
	//共n条鱼 	
	int z0 = 0;
	//左0存活 	
	int y1 = 0;//右1存活 	
	int da, fa;//大小 方向 	
	for (int i = 0; i < n; i++) {
		scanf("%d %d", &da, &fa);
		if (fa == 1) {
			//向右游的存入数组a[]中 			
			a[++y1] = da;
		}
		else 
		{
			if (y1 == 0)
				z0++;
			else
			{
				for (y1; y1 > 0; y1--)
				{
					if (a[y1] > da)
						break;
				}
				if (y1 == 0)
					z0++;
			}
		}
	}
	printf("%d\n", z0 + y1);
	return 0;
}