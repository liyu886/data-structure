#include<bits/stdc++.h>
using namespace std;
struct man
{
    int a;
    int b;
}le[100000],li[100000];
int main()
{
    int ans = 0;
    int n;
    int size = 0;
    cin >> n;
    for(int i = 0;i < n; i++)
    {
        cin >> le[i].a;
        cin >> le[i].b;
    }
    for(int i = 0; i < n ;i++)
    {
        if(le[i].b == 0)
        {
            if(size == 0) ans++;
            else
            {
                int j;
                for(j = size;j>0;j--)
                {
                    if(le[i].a > li[j].a)
                    {
                        size--;
                    }
                    else break;
                }
                if(j == 0) ans++;
            }  
        }
        else
        {
            size++;
            li[size] = le[i];
        }
    }
    cout << ans + size<< endl;
}