#include"function.h"
Node* ReverseMergeList(Node* List1, Node* List2)
{
    Node *curr1 = List1;
    Node *curr2 = List2;
    int count=0,count1=0,count2=0;
    while(curr1 != NULL)
    {
        count1++;
        curr1 = curr1->next;
    }
    while(curr2 != NULL)
    {
        count2++;
        curr2 = curr2->next;
    }
    count = count1+count2;
    int a[count],t=0;
    curr1 = List1;
    curr2 = List2;
    while(curr1 != NULL)
    {
        a[t++] = curr1->value;
        curr1 = curr1->next;
    }
    while(curr2 != NULL)
    {
        a[t++] = curr2->value;
        curr2 = curr2->next;
    }
    for(int i =0;i<t;i++)
    for(int j =0;j<t;j++)
    {
        if(a[i]<a[j])
        {
            int t = a[j];
            a[j]= a[i];
            a[i] = t;
        }
    }
    Node * Chead = new Node(a[t-1]);
    Node *curr = Chead;
    for(int i = t-2;i>=0; i--)
    {
        curr->next = new Node(a[i]);
        curr = curr->next;
    }
    return Chead;
}