#include "helper.h"
Node* ReverseMergeList(Node* list1, Node* list2);
