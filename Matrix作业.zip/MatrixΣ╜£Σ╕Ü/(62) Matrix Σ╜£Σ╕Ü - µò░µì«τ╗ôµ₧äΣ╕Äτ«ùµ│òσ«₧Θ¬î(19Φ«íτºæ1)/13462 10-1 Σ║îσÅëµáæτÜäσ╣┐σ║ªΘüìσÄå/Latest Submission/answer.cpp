#include<bits/stdc++.h>
using namespace std;
struct node
{
	char value;
    node * left;
    node * right;
	node(char v):value(v),left(0),right(0){}
};
void check (int cnt,vector<char> x,vector<char> y,vector<char> &A1,vector<char> &A2,vector<char> &B1,vector<char> &B2)
{
    for(int i=1;i<=cnt;++i)
		A1.push_back(x[i]);
	for(int i=0;i<cnt;++i)
		A2.push_back(y[i]);
	for(int i=cnt+1;i<x.size();++i)
		B1.push_back(x[i]);
	for(int i=cnt+1;i<y.size();++i)
		B2.push_back(y[i]);
}
node* create(vector<char> x,vector<char> y)
{
	if(x.empty()&&y.empty())
		return NULL;
	node* root=new node(x.front());
	vector<char> A1,A2,B1,B2;
	int cnt=0;
	while(y[cnt]!=x.front())
		cnt++;
	check(cnt,x,y,A1,A2,B1,B2);
	root->left=create(A1,A2);
	root->right=create(B1,B2);
	return root;
}
void BFS(node * root)
{
	queue<node *> temp;
	if(root != NULL)
	temp.push(root);
	while(!temp.empty())
	{
		node * q = temp.front();
		temp.pop();
		cout << q->value;
		if(q->left)
		temp.push(q->left);
		if(q->right)
		temp.push(q->right);
	}
}
int main()
{
    int t;
    cin >> t;
    for(int i = 0; i < t ;i++)
    {
        vector<char> x,y;
		char s1[30],s2[30];
		cin >> s1 >> s2;
		for(int i=0;s1[i];i++)
			x.push_back(s1[i]);
		for(int i=0;s2[i];i++)
			y.push_back(s2[i]);
		node* root=create(x,y); 
		BFS(root);
		cout << endl;
    }
}