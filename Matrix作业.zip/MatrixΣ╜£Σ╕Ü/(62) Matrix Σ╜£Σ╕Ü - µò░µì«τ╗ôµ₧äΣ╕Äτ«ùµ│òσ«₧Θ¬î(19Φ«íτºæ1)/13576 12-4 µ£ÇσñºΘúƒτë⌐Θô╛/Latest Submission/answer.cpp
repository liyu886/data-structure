#include<bits/stdc++.h>
using namespace std;
vector<int> g[100];
int inu[1000];
int du[1000];
int vis[1000];
int dfs(int x)
{
    if(du[x] == 0)
    {
        return 1;
    }
    //vis[x] = 1;
    int sum = 0;
    for(int i = 0;i < g[x].size();i++)
    {
        //if(!vis[g[x][i]])
        sum += dfs(g[x][i]);
    }
    //vis[x] = 0;
    return sum;
}
int main()
{
    int n ,m;
    int ans = 0;
    cin >> n >> m;
    for(int i = 1; i <= m; i++)
    {
        int a ,b;
        cin >> a >> b;
        g[a].push_back(b);
        inu[b]++;
        du[a]++;
    }
    for(int i = 1; i <= n; i++)
    {
        if(inu[i] == 0)
        {
            ans += dfs(i);
        }
    }
    cout << ans;
}