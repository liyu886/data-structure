# 13-3 数一数叶数

###问题
请你实现下列函数，计算给定二叉树的叶数：
```
int leaves(const BinaryNode* root);
```

只需提交函数leaves()的实现。请在源程序中包含头文件"BinaryNode.h"。