
#include "BinaryNode.h"

int leaves(const BinaryNode* root){

  if (root==NULL)
    return 0;
  if (root->left == NULL && root->right == NULL)
     return 1; 
   int a = leaves(root->left);
   int b =leaves(root->right);
   return a+b;
}
