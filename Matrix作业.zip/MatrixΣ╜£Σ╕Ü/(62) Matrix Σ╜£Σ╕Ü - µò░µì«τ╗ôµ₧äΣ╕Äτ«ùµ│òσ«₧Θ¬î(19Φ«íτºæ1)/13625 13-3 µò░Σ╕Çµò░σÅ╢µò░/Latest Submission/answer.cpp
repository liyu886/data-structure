#include<bits/stdc++.h>
#include"BinaryNode.h"
using namespace std;
int num;
void bianli(const BinaryNode* root)
{
    if(root == NULL) return;
    if(root->left == NULL&&root->right == NULL)
    {
        num++;
        return;
    }
    bianli(root->left);
    bianli(root->right);
}
int leaves(const BinaryNode* root)
{
    num = 0;
    bianli(root);
    return num;
}