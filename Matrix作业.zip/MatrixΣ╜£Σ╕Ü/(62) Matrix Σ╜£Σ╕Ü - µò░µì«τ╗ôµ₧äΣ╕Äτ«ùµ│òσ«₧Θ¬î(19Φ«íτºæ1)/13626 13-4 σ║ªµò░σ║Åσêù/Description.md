# 13-4 度数序列

假设无向图用邻接表表示，见Graph.h。请实现下列返回无向图度数序列(degree sequence)的函数：
```
vector<int> degreeSequence(const ALGraph &g);
```
注：无向图的度数序列是其顶点度数的非递增序列。