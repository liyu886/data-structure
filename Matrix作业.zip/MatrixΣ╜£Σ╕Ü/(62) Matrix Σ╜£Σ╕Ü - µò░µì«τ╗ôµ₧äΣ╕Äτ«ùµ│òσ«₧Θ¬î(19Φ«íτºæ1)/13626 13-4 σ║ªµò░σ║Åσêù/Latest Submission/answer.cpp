#include<bits/stdc++.h>
#include"Graph.h"
using namespace std;
vector<int> degreeSequence(const ALGraph &g)
{
    vector<int> de;
    for(int i = 0;i < g.order;i++)
    {
        de.push_back(g.adj[i].size());
    }
    for(int i =0 ;i < de.size()-1;i++)
    for(int j = 0;j < de.size()-i-1;j++)
    {
        if(de[j]<de[j+1])
        swap(de[j],de[j+1]);
    }
    return de;
}