#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    cin >> t; 
    for(int i = 0 ;i < t;i++)
    {
        int a,b;
        cin >> a >> b;
        while(a != b)
        {
            if(a < b) b/=2;
            else a/=2;
        }
        cout << a << endl;
    }
}