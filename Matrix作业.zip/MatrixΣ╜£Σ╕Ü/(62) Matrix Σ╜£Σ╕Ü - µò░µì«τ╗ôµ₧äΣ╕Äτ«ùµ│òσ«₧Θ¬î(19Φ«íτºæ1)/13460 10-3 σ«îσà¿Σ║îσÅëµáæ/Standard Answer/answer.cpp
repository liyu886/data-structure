// Problem#: 19758
// Submission#: 4924960
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
// Problem#: 3612
// Submission#: 914663
// The source code is licensed under Creative Commons Attribution-NonCommercial-ShareAlike 3.0 Unported License
// URI: http://creativecommons.org/licenses/by-nc-sa/3.0/
// All Copyright reserved by Informatic Lab of Sun Yat-sen University
#include <iostream> 
#include <vector>
#include <cstdio>
using namespace std; 

int main()
{
    int t,m,n;
    cin>>t;
    while(t--)
    {
        scanf("%d",&m);
        scanf("%d",&n);
        while(m!=n)
        {
            if(m>n) m/=2;
            else if(m<n) n/=2;
        }
        printf("%d",m);
        printf("\n");
    }
    //system("pause");
    return 0 ;
}