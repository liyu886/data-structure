#include<bits/stdc++.h>
using namespace std;
char a[1000];
char b[1000];
void tree(char *mid, char *last)
{
	if(!*mid) return;
    char * p, * q;
    p = last + strlen(last) -1;
    cout << p;
    q = strchr(mid,*p);
    *p = 0;
    p = q - mid + last;
    char temp = *p;
    *p = 0;
    *q = 0;
    tree(mid,last);
    *p = temp;
    tree(q+1,p);
}
int main()
{
    cin >> a >> b;
    tree(a,b);
}