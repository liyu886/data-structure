#include<bits/stdc++.h>
using namespace std;
int main()
{
    string temp;
    cin>> temp;
    stack<int> a;
    a.push(-1);
    int ans = 0;
    for(int i = 0;i < temp.size();i++)
    {
        if(temp[i] == '(')
        a.push(i);
        else
        {
            a.pop();
            if(a.empty()) a.push(i);
            else ans = max(ans , i - a.top());
        }
    }
    cout << ans << endl;
}